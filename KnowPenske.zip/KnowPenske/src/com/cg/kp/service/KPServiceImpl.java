package com.cg.kp.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.kp.dao.IKPDao;

@Service
@Transactional
public class KPServiceImpl implements IKPService{
	@Autowired 
	IKPDao dao;
	
	
	public IKPDao getDao() {
		return dao;
	}


	public void setDao(IKPDao dao) {
		this.dao = dao;
	}


	@Override
	public String getHome() {
		// TODO Auto-generated method stub
		return dao.getHome();
	}

}
