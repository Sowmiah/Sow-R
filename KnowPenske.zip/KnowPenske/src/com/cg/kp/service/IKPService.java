package com.cg.kp.service;

public interface IKPService {

	public String getHome();
}
