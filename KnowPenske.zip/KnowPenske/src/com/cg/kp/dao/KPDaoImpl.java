package com.cg.kp.dao;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class KPDaoImpl implements IKPDao{

	public static final String HOME="home";
	@Override
	public String getHome() {
		// TODO Auto-generated method stub
		return HOME;
	}

}
