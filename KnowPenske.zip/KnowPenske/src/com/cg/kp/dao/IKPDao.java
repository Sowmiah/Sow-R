package com.cg.kp.dao;

public interface IKPDao {

	public String getHome();
}
