package com.cg.kp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.kp.service.IKPService;

@Controller
//@RequestMapping(value="*.obj")
public class KPController {
	
	@Autowired
	IKPService service;

	public IKPService getService() {
		return service;
	}
	
	public void setService(IKPService service) {
		this.service = service;
	}
	
	@RequestMapping("/showHomePage")
	public String showHomePage() {
		return "home";
	}
	
	@RequestMapping("/showProcessPage")
	public String showProcessPage() {
		return "process";
	}
	
	@RequestMapping("/showProjectPage")
	public String showProjectPage() {
		return "project";
	}
}
