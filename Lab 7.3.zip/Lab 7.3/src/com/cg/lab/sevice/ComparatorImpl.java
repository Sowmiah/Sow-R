package com.cg.lab.sevice;

import java.util.Comparator;

import com.cg.lab.bean.EmpBean;

public class ComparatorImpl implements Comparator<EmpBean>{

	@Override
	public int compare(EmpBean obj1, EmpBean obj2) {
		if(obj1.getSal() < obj2.getSal())
			return 0;
		else if(obj1.getSal() > obj2.getSal())
			return(6);
		else
			return(-1);
		
	}

}
