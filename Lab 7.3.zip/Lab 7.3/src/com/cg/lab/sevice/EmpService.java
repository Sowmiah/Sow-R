package com.cg.lab.sevice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.lab.bean.EmpBean;

public class EmpService implements IEmpService {
	HashMap<Integer,EmpBean> hm=new HashMap<Integer,EmpBean>();
	@Override
	public EmpBean addEmp(EmpBean emp) {
		emp=hm.put(emp.getId(), emp);
		//System.out.println("Details added Successfully");	
		return emp;
	}

	@Override
	public void displayDetails() {
			
		for(Map.Entry<Integer, EmpBean> entry:hm.entrySet()){
			//EmpBean emp=new EmpBean();
			//emp=entry.getValue();
			//emp=entry.getKey();
			System.out.println(entry.getKey()+" "+entry.getValue());	
		}
		
	}

	@Override
	public void deleteDetails(int id) {
		for(Map.Entry<Integer, EmpBean> entry:hm.entrySet()){
			if(entry.getKey().equals(id)){
				hm.remove(id);
				System.out.println(id+" Deleted details for the employee id");
			}	
		}
		for(Map.Entry<Integer, EmpBean> entry:hm.entrySet()){
			if(entry.getKey()!=id){
				System.out.println(id+" ID not found");
			}
		}
		
	}

	@Override
	public void sortDetails() {
		ComparatorImpl comparator=new ComparatorImpl();
		List<EmpBean> list=new ArrayList<EmpBean>(hm.values());
		list.sort(comparator);
		for(EmpBean emp : list){
			System.out.println(emp.toString());
		}
	}

	@Override
	public String findDetails(String designation) {
		String ins="";
		for(Map.Entry<Integer, EmpBean> entry:hm.entrySet()){
			if(entry.getValue().getDesignation().equals(designation)){
				//System.out.println("Insurance Scheme is "+entry.getValue().getInsuranceScheme());
			ins=entry.getValue().getInsuranceScheme();
			}
		}
		return ins;
		
	}


	
}
