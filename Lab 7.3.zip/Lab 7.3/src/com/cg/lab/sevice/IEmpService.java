package com.cg.lab.sevice;

import com.cg.lab.bean.EmpBean;

public interface IEmpService {
	public EmpBean addEmp(EmpBean emp);
	public void displayDetails();
	public String findDetails(String designation);
	public void deleteDetails(int id);
	public void sortDetails();
	
}
