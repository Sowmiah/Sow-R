package com.cg.lab.bean;

public class EmpBean {
	private int id;
	private String name;
	private double sal;
	private String designation;
	private String insuranceScheme;
	public EmpBean(int id, String name, double sal, String designation,
			String insuranceScheme) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	@Override
	public String toString() {
		return "EmpBean [id=" + id + ", name=" + name + ", sal=" + sal
				+ ", designation=" + designation + ", insuranceScheme="
				+ insuranceScheme + "]";
	}
	public EmpBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
