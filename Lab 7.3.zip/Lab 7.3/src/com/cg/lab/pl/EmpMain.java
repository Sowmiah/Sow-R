
package com.cg.lab.pl;

import java.util.Scanner;

import com.cg.lab.bean.EmpBean;
import com.cg.lab.sevice.EmpService;
import com.cg.lab.sevice.IEmpService;

public class EmpMain {
	public static void main(String[] args) {
		IEmpService ser=new EmpService();
		Scanner sc=new Scanner(System.in);
		while(true){
			
			System.out.println("1.Add the Employees");
			System.out.println("2.Display the details");
			System.out.println("3.Find insurance Scheme");
			System.out.println("4.Delete the details");
			System.out.println("5.Sort based on salary");
			System.out.println("Enter your Choice");
			int ch=sc.nextInt();
			
			switch(ch){
			case 1:{
				System.out.println("Enter the id: ");
				int id=sc.nextInt();sc.nextLine();
				System.out.println("Enter the salary: ");
				double salary=sc.nextDouble();
				System.out.println("Enter the name: ");
				String name=sc.next();
				System.out.println("Enter the designation");
				String desig=sc.next();
				System.out.println("Enter the insurance Scheme");
				String ins=sc.next();
				
				EmpBean emp=new EmpBean(id,name,salary,desig,ins);
				ser.addEmp(emp);
				System.out.println("Details added successfully");
				break;
			}
			case 2:
			{
				
				ser.displayDetails();
		
				break;
			}
			case 3:
			{
				System.out.println("Enter the designation");
				String desig1=sc.next();
				String ins1=ser.findDetails(desig1);
				System.out.println("Insurance Scheme is : "+ins1);
				break;
			}
			case 4:{
				System.out.println("Enter the id to be deleted");
				int id1=sc.nextInt();
				ser.deleteDetails(id1);
				break;
			}
			case 5:{
				System.out.println("Sorting based on salary");
				ser.sortDetails();
			}
			}
		}
	}
}
