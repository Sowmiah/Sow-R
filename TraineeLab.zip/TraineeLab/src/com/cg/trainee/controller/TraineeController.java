package com.cg.trainee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.bean.LoginBean;
import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.service.ITraineeService;

@Controller
public class TraineeController {
	
	@Autowired
	ITraineeService service;

	public ITraineeService getService() {
		return service;
	}

	public void setService(ITraineeService service) {
		this.service = service;
	}

	@RequestMapping("/loginPage")
	public ModelAndView loginPage() {
		
		LoginBean login=new LoginBean();
		return new ModelAndView("index", "login", login);
	}
	
	@RequestMapping("/loginSuccess")
	public ModelAndView loginSuccess(@ModelAttribute("login") @Valid LoginBean login,
			BindingResult result){
		
		ModelAndView mv = null;
		if(!result.hasErrors()){
		if(login.getUsername().equals("user") && login.getPassword().equals("pass")){
			mv = new ModelAndView("index1");
		}
		else
		{
			return new ModelAndView("failure");
		}
		}
		else
			return new ModelAndView("index", "login", login);
		
	return mv;
		
	}
	
	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee()
	{
		TraineeBean trainee=new TraineeBean();
		return new ModelAndView("addTrainee", "trainee", trainee);
	}
	
	@RequestMapping("/addSuccess")
	public ModelAndView addSuccess(
			@ModelAttribute("trainee") @Valid TraineeBean trainee,
			BindingResult result) {

		ModelAndView mv = null;

		if (!result.hasErrors()) {
			trainee=service.addTrainee(trainee);
			mv = new ModelAndView("addSuccess");
			mv.addObject("traineeId", trainee.getTraineeId() );
			
		} else {
			mv = new ModelAndView("addTrainee", "trainee", trainee);
		}

		return mv;
	}
	@RequestMapping("/retrieveTraineeById")
	public ModelAndView retrieveTraineeById() {
		
		TraineeBean trainee = new TraineeBean();
		ModelAndView mv = new ModelAndView("retrieveTrainee");
		mv.addObject("trainee", trainee);
		mv.addObject("flag", "true");

		return mv;
	}
	
	@RequestMapping("/retrieveTrainee")
	public ModelAndView viewDonation(@ModelAttribute("trainee") TraineeBean trainee) {

		ModelAndView mv = new ModelAndView();

		TraineeBean bean = new TraineeBean();
		bean=service.getTraineeDetails(trainee.getTraineeId());
		
		if (bean != null) {
			
			mv.setViewName("retrieveTrainee");
			mv.addObject("bean", bean);
		} else {
			
			String msg = "Enter a Valid Id!!";
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}

		return mv;
	}
	
	@RequestMapping("/retrieveAll")
	public ModelAndView retrieveAll(){
		ModelAndView mv=new ModelAndView();
		List<TraineeBean> list=service.retrieveAllTrainee();
		if(list.isEmpty()){
			String msg = "There are no Trainee Details";
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		else{
			mv.setViewName("retrieveAll");
			mv.addObject("list", list);
		}
			
		return mv;
		
	}
	
	@RequestMapping("/deleteTraineeById")
	public ModelAndView deleteTraineeById() {
		
		TraineeBean trainee = new TraineeBean();
		ModelAndView mv = new ModelAndView("deleteTrainee");
		mv.addObject("trainee", trainee);
		mv.addObject("flag", "true");

		return mv;
	}
	
	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee(@ModelAttribute("trainee") TraineeBean trainee) {

		ModelAndView mv = new ModelAndView();

		TraineeBean bean = new TraineeBean();
		bean=service.getTraineeDetails(trainee.getTraineeId());
		System.out.println(bean);
		if (bean != null) {
			
			mv.setViewName("deleteTrainee");
			mv.addObject("bean", bean);
		} else {
			
			String msg = "Enter a Valid Id!!";
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}

		return mv;
	}
	
	@RequestMapping("/delete")
	public ModelAndView delete(@ModelAttribute("trainee") TraineeBean trainee){
		
		ModelAndView mv = new ModelAndView();

		TraineeBean bean = new TraineeBean();
		bean=service.getTraineeDetails(trainee.getTraineeId());
		mv.addObject("traineeId", bean.getTraineeId());
		if (bean != null) {
			service.deleteTraineeDetailsbyId(bean);
			
			//mv.setViewName("deleteSuccess");
			List<TraineeBean> list=service.retrieveAllTrainee();
			if(list.isEmpty()){
				String msg = "There are no Trainee Details";
				mv.setViewName("error");
				mv.addObject("msg", msg);
			}
			else{
				mv.setViewName("deleteSuccess");
				mv.addObject("list", list);
			}
			
		} 

		return mv;
		/*ModelAndView mv = new ModelAndView();
		service.deleteTraineeDetailsbyId(trainee);
		mv.setViewName("NewFile");
		return mv;*/	
	}
	
	@RequestMapping("/modifyTraineeById")
	public ModelAndView modifyTraineeById() {
		
		TraineeBean trainee = new TraineeBean();
		ModelAndView mv = new ModelAndView("modifyTrainee");
		mv.addObject("trainee", trainee);
		mv.addObject("flag", "true");

		return mv;
	}
	
	@RequestMapping("/modifybyid")
	public ModelAndView modifybyid(@ModelAttribute("trainee") TraineeBean trainee) {

		ModelAndView mv = new ModelAndView();

		TraineeBean bean = new TraineeBean();
		bean=service.getTraineeDetails(trainee.getTraineeId());
		
		if (bean != null) {
			
			mv.setViewName("modifyTrainee");
			mv.addObject("bean", bean);
		} else {
			
			String msg = "Enter a Valid Id!!";
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}

		return mv;
	}
	
	@RequestMapping("/modify")
	public ModelAndView modify(@ModelAttribute("trainee") TraineeBean trainee){
		
		ModelAndView mv = new ModelAndView();

		TraineeBean bean = new TraineeBean();
		bean=service.getTraineeDetails(trainee.getTraineeId());
		if (bean != null) {
			service.modifybyId(trainee);
			mv.setViewName("modifySuccess");
		} 
		 else {
				
				String msg = "Enter a Valid Id!!";
				mv.setViewName("error");
				mv.addObject("msg", msg);
			}
		return mv;
	}
	
	
	/*@RequestMapping("/loginSuccess")
	public String loginPage(@ModelAttribute("login") LoginBean login) {
		
		
		if(login.getUsername().equals("user") && login.getPassword().equals("pass"))
		{
			 
			return "index1";
		}
		else
			return "failure";
		
		
	}*/
	
	@RequestMapping("/home")
	public String loginSuccess()
	{
		return "index1";
	}
	
}
