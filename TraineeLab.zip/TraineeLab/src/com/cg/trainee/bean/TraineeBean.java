package com.cg.trainee.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="trainee")
public class TraineeBean {
 
	@Id
	private int traineeId;
	
	@NotEmpty(message="Please Enter Trainee Name")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Trainee Name must contain only alphabets")
	private String traineeName;
	
	@NotEmpty(message="Please select Domain")
	private String traineeDomain;
	
	@NotEmpty(message="Please Enter Trainee Location")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Trainee Location must contain only alphabets")
	private String traineeLocation;
	
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	public TraineeBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TraineeBean(int traineeId, String traineeString,
			String traineeDomain, String traineeLocation) {
		super();
		this.traineeId = traineeId;
		this.traineeName = traineeString;
		this.traineeDomain = traineeDomain;
		this.traineeLocation = traineeLocation;
	}
	@Override
	public String toString() {
		return "TraineeBean [traineeId=" + traineeId + ", traineeString="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}
	
	
	
}
