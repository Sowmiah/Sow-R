package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.trainee.bean.TraineeBean;



@Repository
public class TraineeDaoImpl implements ITraineeDao{

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public TraineeBean addTrainee(TraineeBean trainee) {		
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}
	
	@Override
	public TraineeBean getTraineeDetails(int traineeId) {		
		return entityManager.find(TraineeBean.class, traineeId);
	}
	
	@Override
	public TraineeBean deleteTraineeDetails(int traineeId) {		
		return entityManager.find(TraineeBean.class, traineeId);
	}

	
	@Override
	public List<TraineeBean> retrieveAllTrainee() {
		TypedQuery<TraineeBean> query = entityManager.createQuery("SELECT d FROM TraineeBean d", TraineeBean.class);
		return query.getResultList();
	}

	@Override
	public void deleteTraineeDetailsbyId(TraineeBean trainee) {
		entityManager.remove(trainee);
		
	}
	
	@Override
	public void modifybyId(TraineeBean trainee) {
		entityManager.merge(trainee);
		
	}
	
	
}
