package com.cg.trainee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.dao.ITraineeDao;

@Service
@Transactional
public class TraineeServiceImpl implements ITraineeService{

	@Autowired
	ITraineeDao dao;

	public ITraineeDao getDao() {
		return dao;
	}

	public void setDao(ITraineeDao dao) {
		this.dao = dao;
	}

	@Override
	public TraineeBean addTrainee(TraineeBean trainee) {
		
		return dao.addTrainee(trainee);
	}

	@Override
	public List<TraineeBean> retrieveAllTrainee() {
		
		return dao.retrieveAllTrainee();
	}

	@Override
	public TraineeBean getTraineeDetails(int traineeId) {
		
		return dao.getTraineeDetails(traineeId);
	}

	@Override
	public TraineeBean deleteTraineeDetails(int traineeId) {
		
		return dao.deleteTraineeDetails(traineeId);
	}

	@Override
	public void deleteTraineeDetailsbyId(TraineeBean trainee) {
		dao.deleteTraineeDetailsbyId(trainee);
	}

	@Override
	public void modifybyId(TraineeBean trainee) {
		dao.modifybyId(trainee);
		
	}
	
	
	
	
	
	
}
