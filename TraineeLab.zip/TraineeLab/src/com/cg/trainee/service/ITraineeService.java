package com.cg.trainee.service;

import java.util.List;

import com.cg.trainee.bean.TraineeBean;

public interface ITraineeService {

	public TraineeBean addTrainee(TraineeBean trainee);
	public List<TraineeBean> retrieveAllTrainee();
	public TraineeBean getTraineeDetails(int traineeId);
	public TraineeBean deleteTraineeDetails(int traineeId);
	public void deleteTraineeDetailsbyId(TraineeBean trainee);
	public void modifybyId(TraineeBean trainee);
}
