package com.cg.prod.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.prod.bean.ProductBean;
import com.cg.prod.bean.TransactionBean;
import com.cg.prod.service.IProdService;

@Controller
public class ProdController {
	
	@Autowired
	private IProdService service;
	

	public IProdService getService() {
		return service;
	}

	public void setService(IProdService service) {
		this.service = service;
	}

	@RequestMapping("/index")
	public ModelAndView loginPage() {
		
		ProductBean product=new ProductBean();
		return new ModelAndView("index", "product", product);
	}
	
	@RequestMapping("/find")
	public ModelAndView loginSuccess(@ModelAttribute("product") ProductBean product){
		
		ModelAndView mv=new ModelAndView();
		
		int productCode=product.getProductCode();
		System.out.println(product.getProductCode());
		ProductBean bean1 =service.findProduct(productCode);
		List<TransactionBean> list=service.findTransactions(productCode);
		System.out.println(list);
		if (bean1 != null ) {
			if(list.isEmpty()){
				String msg = "No transaction Performed for this Product ";
				mv.setViewName("success");
				mv.addObject("code",bean1.getProductCode());
				mv.addObject("name", bean1.getProductName());
				mv.addObject("isFirst", true);
				mv.addObject("msg", msg);
			}
			else{
			mv.setViewName("success");
			mv.addObject("code",bean1.getProductCode());
			mv.addObject("name", bean1.getProductName());
			mv.addObject("list", list);
			}
			
		} else {
			
			String msg = "Enter a Valid Id!!";
			/*return new ModelAndView("index", "msg", msg);*/
			mv.setViewName("index");
			mv.addObject("isFirst", true);
			mv.addObject("msg", msg);
		}
		
	return mv;
		
	}
}
