package com.cg.prod.dao;

import java.util.List;

import com.cg.prod.bean.ProductBean;
import com.cg.prod.bean.TransactionBean;

public interface IProdDao {

	public ProductBean findProduct(int productCode);
	
	public List<TransactionBean> findTransactions(int productCode);
	
}
