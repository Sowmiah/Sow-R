package com.cg.prod.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.prod.bean.ProductBean;
import com.cg.prod.bean.TransactionBean;


@Repository
@Transactional
public class ProdDaoImpl implements IProdDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	

	@Override
	public ProductBean findProduct(int productCode) {
		ProductBean bean=null;
		
			try {
				TypedQuery<ProductBean> query = entityManager.createQuery("FROM ProductBean where productCode=?", ProductBean.class);
				query.setParameter(1, productCode);
				bean=query.getSingleResult();
			} catch (Exception e) {
				
			}
		
		return bean;
	}



	@Override
	public List<TransactionBean> findTransactions(int productCode) {
		TypedQuery<TransactionBean> query = entityManager.createQuery("FROM TransactionBean where productCode=?", TransactionBean.class);
		query.setParameter(1, productCode);
		return query.getResultList();
	}

	

	
}
