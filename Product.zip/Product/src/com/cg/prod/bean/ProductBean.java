package com.cg.prod.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="product")
public class ProductBean {

	@Id
	private int productCode;

	private String productName;
	private double price;
	private int totalQuantity;
	private Date productDate;
	public ProductBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductBean(int productCode, String productName, double price,
			int totalQuantity, Date productDate) {
		super();
		this.productCode = productCode;
		this.productName = productName;
		this.price = price;
		this.totalQuantity = totalQuantity;
		this.productDate = productDate;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public Date getProductDate() {
		return productDate;
	}
	public void setProductDate(Date productDate) {
		this.productDate = productDate;
	}
	@Override
	public String toString() {
		return "ProductBean [productCode=" + productCode + ", productName="
				+ productName + ", price=" + price + ", totalQuantity="
				+ totalQuantity + ", productDate=" + productDate + "]";
	}
	
	
	
	
}
