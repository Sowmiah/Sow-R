package com.cg.prod.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transaction")
public class TransactionBean {

	@Id
	private int transactionId;
	private int productCode;
	private Date transactionDate;
	private String description;
	private int noofprodspurchd;
	public TransactionBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TransactionBean(int transactionId, int productCode,
			Date transactionDate, String description, int noofprodspurchd) {
		super();
		this.transactionId = transactionId;
		this.productCode = productCode;
		this.transactionDate = transactionDate;
		this.description = description;
		this.noofprodspurchd = noofprodspurchd;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getNoofprodspurchd() {
		return noofprodspurchd;
	}
	public void setNoofprodspurchd(int noofprodspurchd) {
		this.noofprodspurchd = noofprodspurchd;
	}
	@Override
	public String toString() {
		return "TransactionBean [transactionId=" + transactionId
				+ ", productCode=" + productCode + ", transactionDate="
				+ transactionDate + ", description=" + description
				+ ", noofprodspurchd=" + noofprodspurchd + "]";
	}
	
	
}
