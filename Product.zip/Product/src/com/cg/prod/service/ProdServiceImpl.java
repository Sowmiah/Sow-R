package com.cg.prod.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.prod.bean.ProductBean;
import com.cg.prod.bean.TransactionBean;
import com.cg.prod.dao.IProdDao;

@Service
public class ProdServiceImpl implements IProdService {

	@Autowired
	IProdDao dao;
	
	public IProdDao getDao() {
		return dao;
	}

	public void setDao(IProdDao dao) {
		this.dao = dao;
	}

	@Override
	public ProductBean findProduct(int productCode) {
		
		return dao.findProduct(productCode);
	}

	@Override
	public List<TransactionBean> findTransactions(int productCode) {
		
		return dao.findTransactions(productCode);
	}



}
