package com.cg.prod.service;

import java.util.List;

import com.cg.prod.bean.ProductBean;
import com.cg.prod.bean.TransactionBean;

public interface IProdService {
	
	public List<TransactionBean> findTransactions(int productCode);
	
	public ProductBean findProduct(int productCode);

}
