package com.cg.prod.exception;

public class ProductException extends Exception{

	public ProductException(String msg) {
		super(msg);
	
	}

}
