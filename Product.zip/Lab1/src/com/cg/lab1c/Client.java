package com.cg.lab1c;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;


public class Client {
	public static void main(String[] args) {
		SBU sbu=null;
		Resource res = new ClassPathResource("emp.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		
		sbu= (SBU) factory.getBean("sbu1");
		
		System.out.println("SBU details");
		System.out.println("-------------------");
		System.out.println(sbu);
		System.out.println("Employee details:-------------");
		System.out.println(sbu.getEmpList());
	}
}
