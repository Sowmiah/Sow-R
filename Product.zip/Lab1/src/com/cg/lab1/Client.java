package com.cg.lab1;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {

	public static void main(String[] args) {
		
		Employee emp=null;
		Resource res = new ClassPathResource("emp.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		emp=(Employee) factory.getBean("emp");

		System.out.println("Employee details");
		System.out.println("---------------------");
		System.out.println("Employee ID : "+emp.getEmployeeId());
		System.out.println("Employee Name : "+emp.getEmployeeName());
		System.out.println("Employee Salary : "+emp.getSalary());
		System.out.println("Employee BU : "+emp.getBusinessUnit());
		System.out.println("Employee Age : "+emp.getAge());
	}
}
