package com.cg.lab1b;

public class Employee {


		private int empAge;
		private int empId;
		private String empName;
		private double salary;
		private SBU sbu;
		
		public int getEmpAge() {
			return empAge;
		}
		public void setEmpAge(int empAge) {
			this.empAge = empAge;
		}
		public int getEmpId() {
			return empId;
		}
		public void setEmpId(int empId) {
			this.empId = empId;
		}
		public String getEmpName() {
			return empName;
		}
		public void setEmpName(String empName) {
			this.empName = empName;
		}
		public double getSalary() {
			return salary;
		}
		public void setSalary(double salary) {
			this.salary = salary;
		}
		public SBU getSbu() {
			return sbu;
		}
		public void setSbu(SBU sbu) {
			this.sbu = sbu;
		}
		@Override
		public String toString() {
			return "Employee [empAge=" + empAge + ", empId=" + empId
					+ ", empName=" + empName + ", salary=" + salary + ", sbu="
					+ sbu + "]";
		}
		
		
		
		
		
}

