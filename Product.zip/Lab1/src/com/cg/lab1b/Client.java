package com.cg.lab1b;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;



public class Client {
	public static void main(String[] args) {

		Employee emp=null;
		Resource res = new ClassPathResource("emp.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		
		emp=(Employee) factory.getBean("emp1");
		System.out.println(emp);
		
	}

}
