package com.cg.emp.dao;


import java.util.Map;

import com.cg.emp.bean.Employee;

public interface IEmpDao {

	public Employee showEmployees(int empId);
}
