package com.cg.emp.dao;
import java.util.Iterator;
import java.util.List;
import java.util.Map;




import com.cg.emp.bean.Employee;

public class EmpDaoImpl implements IEmpDao {

	
	private List<Employee> list;

	public List<Employee> getList() {
		return list;
	}

	public void setList(List<Employee> list) {
		this.list = list;
	}




	@Override
	public Employee showEmployees(int empId) {
		Employee emp1=null;
		Iterator<Employee> it=list.iterator();
		while(it.hasNext())
		{
			Employee emp=(Employee)it.next();
			if(emp.getEmpId()==empId)
				emp1=emp;
			
		}
		return emp1;
	}

	
	
	
	
	/*private Map<Integer,Employee> map;

	public Map<Integer, Employee> getMap() {
		return map;
	}

	public void setMap(Map<Integer, Employee> map) {
		this.map = map;
	}


	@Override
	public Employee showEmployees(int empId) {
		Employee emp1=null;
		
		for(Map.Entry<Integer, Employee> entry:map.entrySet())
		{
			
			Employee emp= entry.getValue();	
			if(emp.getEmpId()==empId)
			emp1=emp;
		
		}
		return emp1;

	}*/
}