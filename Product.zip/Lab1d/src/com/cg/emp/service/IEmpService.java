package com.cg.emp.service;

import com.cg.emp.bean.Employee;

public interface IEmpService {
	public Employee showEmployees(int empId);
}
