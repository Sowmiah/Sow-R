package com.cg.emp.service;

import com.cg.emp.bean.Employee;
import com.cg.emp.dao.IEmpDao;

public class EmpServiceImpl implements IEmpService {

	private IEmpDao dao;
	
	public IEmpDao getDao() {
		return dao;
	}

	public void setDao(IEmpDao dao) {
		this.dao = dao;
	}

	@Override
	public Employee showEmployees(int empId) {
	
		return dao.showEmployees(empId);
	}

}
