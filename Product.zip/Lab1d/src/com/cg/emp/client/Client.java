package com.cg.emp.client;

import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.emp.bean.Employee;
import com.cg.emp.service.EmpServiceImpl;
import com.cg.emp.service.IEmpService;


public class Client {

	public static void main(String[] args) {
		
		IEmpService service=null;
		Resource res = new ClassPathResource("beans.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		service=(EmpServiceImpl) factory.getBean("service");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Employee Id : ");
		int id=sc.nextInt();
		Employee emp=service.showEmployees(id);
		System.out.println(emp);
		
	}

}
