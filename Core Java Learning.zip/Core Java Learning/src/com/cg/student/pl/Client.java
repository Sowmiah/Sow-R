package com.cg.student.pl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.studapp.bean.Student;

public class Client {
		
	public static void main(String[] args) {
		int choice;
		int ch=1;
		int id1,age1;
		String name1,address1,phno1;
		Student obj = new Student();
		Scanner sc = new Scanner(System.in);
		int n;
		while(ch!=4){
		System.out.println("Enter your choice");
		System.out.println("1.Add New Students");
		System.out.println("2.Show all students");
		System.out.println("3.Display Students By ID ");
		System.out.println("4.Exit");
		choice=sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter the no. of records to be added");
				n = sc.nextInt();
				for(int i=0;i<n;i++)
				{
					System.out.println("Enter the ID :");
					id1=sc.nextInt();
					System.out.println("Enter the Name:");
					name1=sc.next();
					System.out.println("Enter the Age ");
					age1=sc.nextInt();
					System.out.println("Enter the Mobile No. ");
					phno1=sc.next();
					System.out.println("Enter the Address");
					address1=sc.next();
					obj.addNewStudent(id1,name1,age1,phno1,address1);
					
				}
				
				break;
			case 2:
				obj.showAllStudents();
				break;
			case 3:
				//List<Student> list=new ArrayList<Student>();
				
				obj.displayStudentsById();
				break;
			case 4:
				System.exit(0);
				break;
			default:
				System.out.println("Enter the correct option");
			}
		} 
		sc.close();

	}
}
