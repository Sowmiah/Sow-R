package com.cg.studapp.bean;

import java.util.*;

public class Student  {
	private int id;
	private String name;
	private int age;
	private String mobileno;
	private String address;
	Student array[] = new Student[20];
	int i;

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(int id, String name, int age, String mobileno, String address) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.mobileno = mobileno;
		this.address = address;

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age
				+ ", mobileno=" + mobileno + ", address=" + address + "]";
	}

	public void addNewStudent(int id2, String name2, int age2,
			String mobileno2, String address2) {
		
		Student obj = new Student(id2, name2, age2, mobileno2, address2);
		array[i] = obj;
		System.out.println("Records are added");
		//i++;
	}

	public void displayStudentsById() {
		
	}

	public void showAllStudents() {
		for(int i=0;i<array.length;i++){
			if(array!=null){
				//System.out.println();
				System.out.println(array[i].toString());
			}
			else
				break;
		}
	}

	/*@Override
	public int compareTo(Object arg0) {
		// TODO Auto-generated method stub
		return 0;
	}*/
}
