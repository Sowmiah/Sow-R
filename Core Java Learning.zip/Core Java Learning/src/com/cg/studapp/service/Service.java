package com.cg.studapp.service;

public interface Service {
	
	public void addNewStudent();
	public void showAllStudents();
	public void displayStudentsById();
}
