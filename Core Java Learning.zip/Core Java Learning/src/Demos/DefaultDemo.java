package Demos;

public class DefaultDemo {

	public static void main(String[] args) {
		String str = null;
		str.equals("Hello");

	}

}
