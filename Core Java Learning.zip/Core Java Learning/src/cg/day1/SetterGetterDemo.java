package cg.day1;

import java.util.Scanner;

public class SetterGetterDemo {
		private int age;
		private String name;
		private float salary;
		
		public int getAge(){
			Scanner sc=new Scanner(System.in);
			return age;
		}

		@Override
		public String toString() {
			return "SetterGetterDemo [age=" + age + "]";
		}

		public SetterGetterDemo(int age, String name, float salary) {
			super();
			this.age = age;
			this.name = name;
			this.salary = salary;
		}

		public SetterGetterDemo() {
			super();
		}
		
}
