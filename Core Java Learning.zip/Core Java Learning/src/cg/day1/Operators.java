package cg.day1;

public class Operators {
	public static void main(String args[])
	{
		System.out.println(25>>>4);
		System.out.println(25<<4);
		System.out.println(5&4);
		System.out.println(5|4);
		System.out.println(5^4);
		System.out.println(-1>>>24);
		System.out.println(64>>3);
	}

}
