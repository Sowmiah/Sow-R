package cg.day1;

abstract public class B {

	public static void main(String[] args) {
		String num="java";
		String num1="java";
		
		if(num==num1){
			System.out.println(num==num1);
		}
		if(num.equals(num1)){
			System.out.println(num.equals(num1));
		}

	}

}
