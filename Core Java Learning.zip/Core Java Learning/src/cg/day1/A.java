package cg.day1;

class A {

}

class C extends A
{
	 void display(){
		System.out.println("1");
	}
}
 class D
 {
	 public static void main(String[] args) {
		C  b= new C();
		
	
		
	}
 }