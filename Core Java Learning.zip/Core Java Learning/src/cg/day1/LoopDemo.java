package cg.day1;

public class LoopDemo {

	public static void main(String[] args) {
		/*for(int i=0; i<10;i++)
		{
			System.out.println("Value is " +i); 
			}*/
		/*int ctr=5;
		while(ctr<=10)
		{
			System.out.println(ctr);
			ctr++;
		}*/
		/*int ctrl=7;
		do{
			System.out.println(ctrl);
			ctrl=ctrl+2;
		}while(ctrl<=16);*/
		/*Its working on collections*/
		/*int myArray[]={2,4,6,8,10};
		for(int element : myArray)
		{
			System.out.println(element);
		}*/
		String ch="Winter";
		
		switch(ch)
		{
			case "Winter" :
				System.out.println("Month is December or January or February");
				break;
			case "Summer" :
				System.out.println("Month is March or April or May");
				break;
			case "Spring" :
				System.out.println("Month is June or July or August");
				break;
			case "Autumn" :
				System.out.println("Month is September or October  or November ");
				break;
				default:
					System.out.println("No season");
		
		}
		
	}

}
