package cg.day1;



public class Seasons {


	public static void main(String args[]) {
		String month="July";	
		
			
		switch (month) {
		case "January":
			System.out.println("Season is Winter");
			break;
		case "February":
			System.out.println("Season is Winter");
			break;
		case "March":
			System.out.println("Season is Summer");
			break;
		case "April":
			System.out.println("Season is Summer");
			break;
		case "May":
			System.out.println("Season is Summer");
			break;
		case "June":
			System.out.println("Season is Spring");
			break;
		case "July":
			System.out.println("Season is Spring");
			break;
		case "August":
			System.out.println("Season is Spring");
			break;
		case "September":
			System.out.println("Season is Autumn");
			break;
		case "October":
			System.out.println("Season is Winter");
			break;
		case "November":
			System.out.println("Season is Winter");
			break;
		case "December":
			System.out.println("Season is Winter");
			break;
		default:
			System.out.println("Invalid Month");
			
		
		}
	}
}

	
	
