package cg.day5;

import java.util.Comparator;

public class EmployeeComparator implements Comparator<Employee>{

	@Override
	public int compare(Employee obj1, Employee obj2) {
		if(obj1.getEmployeeId() == obj2.getEmployeeId())
			return 0;
		else if(obj1.getEmployeeId() > obj2.getEmployeeId())
			return(6);
		else
			return(-1);

	}

}
