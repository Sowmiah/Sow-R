package cg.day5;

public class DataGeneric<E> {
	private E item;

	public E getItem() {
		return item;
	}

	public void setItem(E item) {
		this.item = item;
	}
	

}
