package cg.day5;

public class TestDataGeneric {
	public static void main(String[] args) {
		DataGeneric<Integer> obj1=new DataGeneric<Integer>();
		DataGeneric<String> obj2=new DataGeneric<String>();
		
		obj1.setItem(101);
		obj2.setItem("Ajay");
		
		int n=(Integer) obj1.getItem();//Wrapper class
		System.out.println(n);
		
		String str=(String) obj2.getItem();
		System.out.println(str);
	}
}
