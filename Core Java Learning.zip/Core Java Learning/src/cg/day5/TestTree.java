package cg.day5;



import java.util.*;

public class TestTree {
	public static void main(String[] args) {
		//Collection<String> list=new TreeSet<String>();//Sorted
		//Collection<String> list=new HashSet<String>();
		
		//Collection<String> list=new ArrayList<String>();//Will not sort Collections
		
		List<String> list=new ArrayList<String>();
		
		list.add("Babitha");
		list.add("Ajay");
		list.add("David");
		list.add("David");
		
		//Collections.shuffle(list);
		//Collections.sort(list);
		//Collections.reverse(list);		
		//Collections.min(list);
		Collections.max(list);
		
		for(String str: list){
		System.out.println(str);	
		}
		
	}
}
