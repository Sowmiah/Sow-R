package cg.day5;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TestCollection {
	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<String>();
		//List<String> list=new LinkedList<String>();
		//Collection<String> list=new TreeSet<String>();
		list.add("one");
		list.add("1");
		list.add("two");
		list.add("three");
		list.add(1, "four");
		list.add(0,"eight");
		System.out.println(list);
		System.out.println(list.get(2));
		//System.out.println(list.get(3));//ArrayIndexOutOfBoundException
		System.out.println(list.size());
		System.out.println(list.remove(0));
		System.out.println(list);
		list.get(1);
		//String str = (String)list.get(1);
		//System.out.println(str);
		System.out.println("Iteration using get method");
		for(int i=0;i<list.size();i++){
			String str=(String) list.get(i);
			System.out.println(str);
			}
		System.out.println("Iteration using get method");
		for(Object obj :list)
		{
			String str = (String) obj;
			System.out.println(str);
		}
		Iterator<String> it=list.iterator();
		while(it.hasNext()){
		it.remove();//IllegalStateException before iterating we cant remove an item
		String str=(String) it.next();
		System.out.println(str);
		}
		//list.forEach(p->System.out.println(p));
		
	}
}
