package cg.day5;

import java.util.*;
import java.util.Map.Entry;

public class TestEmployeeMap {
	public static void main(String[] args) {
		Map<Integer,Employee> map=new HashMap<Integer,Employee>();
		map.put(1001, new Employee(1001,"Babitha"));
		map.put(1002, new Employee(1002,"Ajay"));
		map.put(1003, new Employee(1003,"David"));
		map.put(1004, new Employee(1004,"Bhavya"));
		map.put(1005, new Employee(1005,"Neema"));
		if(map.containsKey(1001)){
			Employee emp = map.get(1001);
			System.out.println(emp.getEmployeeId()+" "+emp.getEmployeeName());
		}
		Set<Integer> keys=map.keySet();//contains keys
		Collection<Employee> values = map.values();//contains values
		
		Set<Entry<Integer,Employee>> entrySet = map.entrySet();//entryset contains both keys and values
		
		for(Entry<Integer,Employee> e:entrySet)
		{
			System.out.println(e.getKey()+" "+e.getValue().getEmployeeName());
		}
		
	}
}
