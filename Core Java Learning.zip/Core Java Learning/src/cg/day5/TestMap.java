package cg.day5;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class TestMap {
	public static void main(String[] args) {
		Map<Integer,String> map=new HashMap<Integer,String>();
		map.put(3004, "Babitha");
		map.put(2001, "Ajay");
		map.put(4002, "David");
		map.put(8009, "Bhavya");
		map.put(6001, "Neema");
		if(map.containsKey(2001)){
			System.out.println("Name = "+map.get(2001));
			map.remove(2001);
		}
		else
		{
			System.out.println("NOT FOUND");
		}
		System.out.println(map);
	}
}
