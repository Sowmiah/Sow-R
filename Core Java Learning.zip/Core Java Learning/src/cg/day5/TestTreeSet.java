package cg.day5;

import java.util.*;


public class TestTreeSet {
	public static void main(String[] args) {
		Set<Employee> list=new TreeSet<Employee>(new EmployeeComparator());
		
		Employee e1=new Employee(2001,"Radha");
		Employee e2=new Employee(1001,"Ajay");
		Employee e3=new Employee(3003,"Seema");
		
		list.add(e1);
		list.add(e2);
		list.add(e3);
		//list.add(null);//Does not allow null value
		//Collections.sort(list);
		//Collections.sort(list,new EmployeeComparator());
		
		for(Employee emp: list){
			//System.out.println(emp);//use to getter methods
			if(emp!=null)
			System.out.println(emp.getEmployeeId()+" "+emp.getEmployeeName());	
			}
			}
}
