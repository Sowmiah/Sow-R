package cg.day5;

public class Employee implements Comparable<Employee>{
	private int employeeId;
	private String employeeName;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int employeeId, String employeeName) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	@Override
	public int compareTo(Employee obj) {
		// Use Overide or implement methods
		//To sort the Employee the compareTo method is used
		if(this.employeeId == obj.employeeId)
		return(0);
		else if(this.employeeId > obj.employeeId)
			return(6);//Some positive value
		else
			return(-1);
	}
	
	
}
