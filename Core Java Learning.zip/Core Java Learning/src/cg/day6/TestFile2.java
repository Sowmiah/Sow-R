package cg.day6;

import java.io.*;

public class TestFile2 {
	public static void main(String[] args) {
		try {
			int empid=1001;
			String empName="John";
			double salary = 9500.65;
			PrintWriter out=new PrintWriter("emp.txt");
			
			out.println(empid);
			out.println(empName);
			out.println(salary);
			out.flush();
			System.out.println("Data Stored");
		}
		catch (FileNotFoundException e) {
			System.out.println(" FILE NOT FOUND ");
		}
		catch(IOException e){
			System.out.println("read/write fail");
			
		}
	}
}
