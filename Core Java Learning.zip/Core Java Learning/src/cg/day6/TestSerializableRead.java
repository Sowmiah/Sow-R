package cg.day6;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class TestSerializableRead {
	public static void main(String[] args) throws Exception{
		
		FileInputStream fin=new FileInputStream("emp.dat");
		ObjectInputStream in=new ObjectInputStream(fin);
		
		Employee emp=(Employee)in.readObject();
		System.out.println(emp.getEmployeeId()+" "+emp.getEmployeeName());
		
	}
}
