package cg.day6;
import java.io.*;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.LineNumberReader;

public class TestFile {
	public static void main(String[] args) throws IOException {

		try {
			FileReader fin=new FileReader("D:/sample.txt");
			//BufferedReader buf=new BufferedReader(fin);
			//FileInputStream fin = new FileInputStream("D:/sample.txt");
			//BufferedInputStream buf=new BufferedInputStream(fin);
			LineNumberReader buf=new LineNumberReader(fin);
			FileWriter fr=new FileWriter("sample2.txt");
			while(buf.ready()){//file writer
				String str=buf.readLine();
				fr.write(str);
				fr.flush();
			}
			System.out.println("Copied successfully");
			/*while(buf.ready()){//with Linenumberreader
				String str=buf.readLine();
				System.out.println(buf.getLineNumber()+" "+str);
			}*/
			
			/*while(buf.ready()){//with buff reader
				
				char ch=(char)buf.read();
				System.out.println(ch);
			}*/
			/*while (fin.available()>0) {
				//char ch=(char)fin.read();//without buffer reader
				char ch=(char)buf.read();
				System.out.println(ch);
			}*/
			fin.close();
		} catch (FileNotFoundException e) {
			System.out.println("FILE NOT FOUND");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("read/write failed");
			e.printStackTrace();
		}
	}
}
