package cg.day6;

import java.io.File;

public class File3 {
public static void main(String[] args) {
	try {
		File file=new File("sample.txt");
		System.out.println(file.exists());
		System.out.println(file.isFile());
		System.out.println(file.length());
		System.out.println(file.isDirectory());
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
