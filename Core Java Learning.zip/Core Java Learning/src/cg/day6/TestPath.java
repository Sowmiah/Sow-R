package cg.day6;

import java.nio.file.Path;
import java.nio.file.Paths;

public class TestPath {
	public static void main(String[] args) {
		Path path=Paths.get("C:/Program Files/Java/jdk1.7.0_80");
		System.out.println(path.getNameCount());
		System.out.println(path.getName(0));
		System.out.println(path.getRoot());
		for(int i=0;i<path.getNameCount();i++){
			System.out.println(path.getName(i));
		}
	}
}
