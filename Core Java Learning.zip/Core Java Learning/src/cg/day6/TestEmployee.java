package cg.day6;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestEmployee {
	public static void main(String[] args)throws Exception {//Bad way of handling exception is using throws
		//Write object to a file
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter Emp Id");
		int id=scr.nextInt();scr.nextLine();
		System.out.println("Enter the Employee Name");
		String name=scr.nextLine();
		System.out.println("Enter the Salary");
		double salary = scr.nextDouble();
		
		Employee emp=new Employee();
		emp.setEmployeeId(id);
		emp.setEmployeeName(name);
		emp.setSalary(salary);
		Pattern p=Pattern.compile("[0-9]{4}");
		Matcher m=p.matcher(String.valueOf(id));
		if(m.matches())
		{
		System.out.println(name);
		FileOutputStream fout=new FileOutputStream("emp.dat");
		ObjectOutputStream out=new ObjectOutputStream(fout);
		out.writeObject(emp);
		out.close();
		scr.close();
		System.out.println("Objected Persisted");
		}
		else
			System.out.println("Object not persisted");
 }
}
