package cg.day6;

import java.io.*;

public class TestDirectory {
	public static void main(String[] args) {
		File file=new File("C:/Program Files");
		if(file.isDirectory())
		{
			File [] str=file.listFiles();
			for(File s:str){
				System.out.println(s.getName()+" "+(s.isDirectory()?"directory":"file"));
			}
		}
	}
}
