package cg.day4;

import java.util.Arrays;

public class TestArray {
	public static void sum(int...num){
		int s=0;
		for(int n : num){
			s+=n;
			//return(s);
		}
		
	}
	public static void print(int [] arr){
		for(int n : arr)
		{
			System.out.print(n+" ");
		}
		System.out.println("\n..............");
		
	}
	public static void main(String[] args) {
		
		int [] arr={10,2,13,4,5};
		System.out.println(arr.length);
		/*for(int i=0;i<arr.length;i++){
		System.out.print(arr[i]+" ");
		}
		System.out.println("\n..............");
		*/
		print(arr);
		Arrays.sort(arr);
		print(arr);
		print(arr);
		//System.out.println(sum(arr));
		String [] array = new String[5];//initializing
		array[0]="Chennai";
		String[] str={"bangalore","mumbai","chennai"};//declaring
		for(String s : str)
		{
			System.out.println(s.toUpperCase());
		}
		
	}
}
