package cg.day4;

public class TestAccount {

	public static void main(String[] args) {
		Account obj = new Account();
		try{
		obj.withdraw(0);
		}
		catch(BalanceException e)
		{
			e.printStackTrace();
		}

	}

}
