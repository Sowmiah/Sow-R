package cg.day4;

public class BalanceException extends RuntimeException{

	public BalanceException(String message)
	{
		super(message);
	}
}
