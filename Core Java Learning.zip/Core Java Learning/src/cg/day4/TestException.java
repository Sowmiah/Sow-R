package cg.day4;

public class TestException {
	public static int divide(int a,int b)throws Exception
	{
		if(b==0)
		{
			throw new Exception("ZERO VALUE");
		}
		return(a/b);
	}

	public static void main(String[] args) {
		
		try
		{
		int a=Integer.parseInt(args[0]);//ArrayIndexOutOfBoundException and NumberFormatException may occur
		int b=Integer.parseInt(args[1]);//ArrayIndexOutOfBoundException and NumberFormatException may occur
		//int c=a/b;//ArithmeticException may occur
		int d=divide(a,b);
		System.out.println("Result = "+d);
		}
		
		catch(NumberFormatException e){
			System.out.println(" NOT  A NUMBER");
			System.out.println(e.getMessage());//to print the error message
			e.printStackTrace();
		}
		
		catch(ArrayIndexOutOfBoundsException e){
			//e.printStackTrace();
			System.out.println("PARAMETER MISSING");
		}
		
		catch(ArithmeticException e){
			//e.printStackTrace();
			System.out.println("Second Parameter Zero");
			//return;
		}
		catch(Exception e)
		{
			System.out.println("Exception");
		}
		/*//Multi catch block
		 catch(NumberFormatException | ArithmeticException | ArrayIndexOutOfBoundsException{
		 System.out.println("e");
		 }*/
		finally{
		System.out.println(" END ");//final block gets executed at any case
		}
	}
}
