package cg.day4;

public class Account {

	public void withdraw(int amt) throws BalanceException{
		if(amt > 0){
			System.out.println("WITHDRAW SUCCESS");
		}
		else
		{
			throw new BalanceException("AMOUNT ZERO");
		}
	}
}
