package cg.day2;

public class SuperDemo {

	public static void main(String[] args) {
		C objC=new C();
		//System.out.println(objC.i);
		//objC.show();
	}

}
class A{
	int i=1;
	
	public A() {
		super();
		System.out.println("Constructor A");
	}

	void show()
	{
		System.out.println("A");
	}
}
class B extends A{
	int i=11;
	public B() {
		super();
		System.out.println("Constructor B");
	}
	void show()
	{
		System.out.println("B");
	}
}
class C extends B{
	int i=111;
	{
		System.out.println(super.i);
	}
	
	public C() {
		super();
		System.out.println("Constructor C");
	}

	void show()
	{
		super.show();
		System.out.println("C");
	}

}