package cg.day2;
import static java.lang.Math.*;
public class StringDemo {
	public static void main(String[] args){
		String s1="Rajeev";
		String s2="Rajeev";
		
		System.out.println(s1==s2);
		System.out.println("s1.equals(s2)"+s1.equals(s2));
		String s3=new String("Rajeev");
		String s4=new String("Rajeev");
		s1+="Mohan";
		System.out.println(s1);
		
		
		System.out.println("s3==s4"+s3==s4);
		System.out.println("s3.equals(s4)"+s3.equals(s4));
		
		StringBuffer s5=new StringBuffer("Rajeev");
		StringBuffer s6=new StringBuffer("Rajeev");
		System.out.println(s5==s6);
		System.out.println("s5.equals(s6) "+s5.equals(s6));
		
		String country="India";
		char c=country.charAt(0);
		System.out.println(c);
		System.out.println(country.equalsIgnoreCase("INDIA"));
		System.out.println(country.toUpperCase());
		System.out.println(country.toLowerCase());
		System.out.println(country.length());
		System.out.println(country.isEmpty());
		
		System.out.println(sqrt(25));
		System.out.println(max(10,5));
	}

}
