package cg.day2;

public class ClassFacilities {
	int i=10;
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(j);
		ClassFacilities cf1=new ClassFacilities();
		System.out.println();

	}

}
