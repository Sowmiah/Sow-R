package cg.day2;

import cg.day1.LoopDemo;

//Top level class can have only public and default i.e package level accessibility
public class ClassDemo {
	// Fields,States,Attributes and Instance Variable
	private int age;
	private String name;
	// static variables or class variables
	private static int myVar1 = -99;
	private static String country = "India";

	// Behaviour,Function,Action
	// purpose -- to manipulate attributes

	// Instance Method
	public void showDetails() {
		age = 10;
		name = "abc";
		System.out.println("Hello " + name + " you are " + age + " years old");

	}

	// Static Method
	public static void myStatic() {
		System.out.println(myVar1);
		System.out.println(country);
	}

	public static void main(String[] args) {
		myStatic();// calling static method directly
		ClassDemo cd = new ClassDemo();// Object Creation
		cd.showDetails();// calling instance method via object
		System.out.println(cd.age);// printing instance property
		System.out.println(cd.country);// printing static property
		System.out.println(cd);// printing object [toString() called]
		// never use System.out.println(cd.myStatic) biggest flaw
		LoopDemo ld = new LoopDemo();
		//ld.main(args);
	}

	@Override
	public String toString() {
		return "ClassDemo [age=" + age + ", name=" + name + "]";
	}
}
