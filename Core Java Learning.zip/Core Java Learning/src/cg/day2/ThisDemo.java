package cg.day2;

public class ThisDemo {
	private int myVar;
	private String name;
	
	
	public ThisDemo() {
		this(10,"Murali");
		System.out.println("I'm inside default constructor");
	}


	public ThisDemo(int myVar, String name) {
		this(100,-99);
		this.myVar = myVar;
		this.name = name;
		System.out.println("I'm inside Parameterized Constructor "+this.myVar+","+this.name);
	}
	
	public ThisDemo(int myVar,int i) {
		this.myVar = myVar;
		int z=i;
		System.out.println("I am inside Parameterized Constructor " +this.myVar+ ","+z);
	}


	public static void main(String[] args){
		ThisDemo td=new ThisDemo();
		//ThisDemo td1=new ThisDemo(10,"Sowmiah");
	}
}
