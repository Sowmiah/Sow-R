package cg.day3;

import java.util.regex.Pattern;

public class RegexExample3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Pattern.matches("[amn]","abcd"));
		System.out.println(Pattern.matches("[amn]","a"));
		//System.out.println(Pattern.matches("\\, arg1))
		System.out.println(Pattern.matches("\\d", "abc"));
		System.out.println(Pattern.matches("\\d", "1"));
		System.out.println(Pattern.matches("\\d", "4443"));
		System.out.println(Pattern.matches("\\d", "323abc"));
		System.out.println(Pattern.matches("\\d", "m"));
		
		System.out.println(Pattern.matches("\\D","abc"));
		System.out.println(Pattern.matches("\\D","a"));
	}

}
