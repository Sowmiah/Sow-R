package cg.day3;

import java.util.Scanner;

public class ScannerDemo {
	public static void main(String[] args){
		Scanner input= new Scanner(System.in);
		System.out.println("Enter Value.. ");
		int myIntVal=input.nextInt();
		System.out.println("Enter Value.. ");
		System.out.println("myIntVal " + myIntVal);
		System.out.println("Enter Value.. ");
		int myIntVal2=input.nextInt();
		System.out.println("myIntVal2 " + myIntVal2);
		Scanner strInput=new Scanner(System.in);
		System.out.println("Enter a String value..");
		String myStr=strInput.nextLine();
		System.out.println("MyStr is "+myStr);
		input.close();
		strInput.close();
	}

}
