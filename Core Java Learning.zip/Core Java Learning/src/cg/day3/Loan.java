package cg.day3;



public abstract class Loan {
	 
	public static double roi = 7.5;
	

	public abstract double calLoan(double Loan);
}

