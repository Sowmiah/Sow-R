package cg.day3;

public class FinalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
class FirstClass {
	final int MYINT = 100;
	
	public final void myMethod(){
		
		//MYINT = MYINT+10;	
	}
}

//class SecondClas extends FirstClass{
//	public final void myMethod(){
//		
//	}
//}
//