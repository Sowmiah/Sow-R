package cg.day3;

public class OverridingDemo {
	public static void main(String[] args) {
		Animal animal1=new Animal();
		animal1.eating();
		animal1.walking();

		animal1=new Cat();//here we use the reference animal1 to call the method of cat and dog and rabbit
		animal1.eating();
		animal1.walking();

		animal1=new Dog();
		animal1.eating();
		animal1.walking();

		animal1=new Rabbit();
		animal1.eating();
		animal1.walking();

		//Object o=new Button();//o (animal1 showing it is polymorphic object)
		                      //(Button is a in built method and here it is showing object o
		                       //is holding
		//o=animal1;
			}

		}

		class Animal
		{
			public void eating()
			{
				System.out.println("Animal can eat");
			}
			public void walking()
			{
				System.out.println("Animal can walk");
			}
		}

		class Rabbit extends Animal //here we use extends animal because we are creating only object for animal
		                            //so with the object of animal we access methods
		{
			public void eating()
			{
				System.out.println("Rabbit eats grass");
			}
			public void walking()
			{
				System.out.println("Rabbit hops..");
			}
			
		}

		class  Dog extends Animal
		{
			public void eating()
			{
				System.out.println("Dog eats biscuit");
			}
			public void walking()
			{
				System.out.println("Dog jumps...");
			}
			
		}


		class  Cat extends Animal
		{
			public void eating()
			{
				System.out.println("cat eats fish");
			}
			public void walking()
			{
				System.out.println("cat walks silently...");
			}

}
