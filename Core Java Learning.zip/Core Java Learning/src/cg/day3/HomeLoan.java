package cg.day3;

import java.util.Scanner;

public class HomeLoan extends Loan {
	public double calLoan(double roi) {
		double homeLoan = 0;
		double emi = 0;
		if (roi <= 7.49) {
			System.out.println("Loan can not be provided ROI is less than 7.5");
			emi = -1;
		}else if(roi >= 7.5){
			System.out.println("Enter Loan Amount");
			Scanner input = new Scanner(System.in);
			homeLoan = input.nextDouble();
		
			if(homeLoan >= 2000001){
				System.out.println("Loan Amount is high..");
				emi = -1;
			}else{
				emi = (homeLoan * roi * 20 / 100) /240;
			}
		}
		return emi;
		
	}

}
