package cg.day3;
import java.util.EnumSet;
public class EnumDemo {
	

		public enum Food{
			SAMOSA,FINGERFRIES,BADA,HOTDOG;
			public static Food favoritefood(){
				return HOTDOG;
			
		}
	}

	public static void main(String args[]) {
		for (Food f :Food.values()) {
			System.out.println("Food: " + f);
			if (f == Food.FINGERFRIES) {
				System.out.println("Food: " + f);
			}
			if (f == Food.FINGERFRIES) {
				System.out.println("I found the fries");
			}
			if (f == Food.favoritefood()) {
				System.out.println("I found my favorite food");
			}
		}
		for (Food f : EnumSet.range(Food.FINGERFRIES,Food.HOTDOG)) {
			System.out.println("More Food: " + f);
		}
	}
}
