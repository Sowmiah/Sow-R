package cg.day3;

public class LoanClient {
	public static void main(String[] args){
		Loan hl = new HomeLoan();
		double emi = hl.calLoan(Loan.roi );
				System.out.println("Monthly EMI is "+emi);
		//LoanInterface li= new HomeLoanImplInterface();
		//System.out.println(li.calLoan(HomeLoanImplInterface.ROI));
		
	}

}
