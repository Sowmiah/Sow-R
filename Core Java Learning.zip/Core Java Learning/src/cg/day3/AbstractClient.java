package cg.day3;

public class AbstractClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AbstractImplClass aic = new AbstractImplClass();
		System.out.println(aic.x);
		System.out.println(AbstractClass.z);
		aic.meth3();
		aic.myMeth();
	}

}
