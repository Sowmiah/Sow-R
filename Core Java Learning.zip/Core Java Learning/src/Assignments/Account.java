package Assignments;

public class Account {
private long accNum;
private double balance;
Person1 accHolder;
public Account() {
	super();
	// TODO Auto-generated constructor stub
}
public Account(long accNum, double balance, Person1 accHolder) {
	super();
	this.accNum = accNum;
	this.balance = balance;
	this.accHolder = accHolder;
}
public long getAccNum() {
	return accNum;
}
public void setAccNum(long accNum) {
	this.accNum = accNum;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public Person1 getAccHolder() {
	return accHolder;
}
public void setAccHolder(Person1 accHolder) {
	this.accHolder = accHolder;
}
void displayAccount(Person1 accHolder,double balance){

}
void deposit(Person1 accHolder,double balance){
	
}
void withdraw(Person1 accHolder,double balance){
	
}
}
