package Assignments;

public class CheckNumber {

	public static void main(String args[]) {
		
		String number = args[0];
		int no = Integer.parseInt(number);
		
		if(no>0){
			System.out.println("Number is positive");
		}
		
		else{
			System.out.println("Number is negative");
		}

	}

}
