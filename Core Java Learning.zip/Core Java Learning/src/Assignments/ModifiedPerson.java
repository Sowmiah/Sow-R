package Assignments;

import java.util.regex.Pattern;


public class ModifiedPerson {
	String firstName;
	String lastName;
	String gender;
	String phoneNumber;
	Gender gen;
	
	public enum Gender{
		M,F,m,f;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public ModifiedPerson() {
		super();
		
	}

	
	public ModifiedPerson(String firstName, String lastName, String gender,String phoneNumber,Gender gen) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.phoneNumber=phoneNumber;
		this.gen=gen;
	}
	
	public boolean acceptPhno(String phoneNumber){
		boolean b2 = Pattern.compile("[7-8]{1}[0-9]{9}").matcher(phoneNumber).matches();
		return b2;
		
	}
	
	/*public Gender checkGender(Gender gen)
	{
		for (Gender g : Gender.values())
		{
			gen=g;
		}
		return gen;
	}*/
	
}
