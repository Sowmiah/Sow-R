package Assignments;

public class Person1 {
	private String name;
	private float age;
	public Person1() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Person1(String name, float age) {
		super();
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	
}
