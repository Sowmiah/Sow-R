package Assignments;

public class ClientAccount {
	public static void main(String[] args) {
		Person1 p1=new Person1("Smith",2000);
		Person1 p2=new Person1("Kathy",3000);
		
		Account obj1=new Account();
		obj1.deposit(p1, 2000);
		
		Account obj2=new Account();
		obj1.withdraw(p2,2000);
		
		
		
	}
}
