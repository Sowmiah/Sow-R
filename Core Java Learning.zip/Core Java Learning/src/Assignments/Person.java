package Assignments;

public class Person {

	String firstName;
	String lastName;
	String gender;
	

	
	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public Person() {
		super();
		
	}

	
	public Person(String firstName, String lastName, String gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}


	/*public static void main(String[] args)
	{
		Person p = new Person();
		System.out.println(p.firstName);
		System.out.println(p.lastName);
		System.out.println(p.gender);
	}*/
}
