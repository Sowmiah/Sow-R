package Assignments;

import java.util.Scanner;

public class StringOperator {

	public void appendOperation(String word1,String word2){
		
		StringBuffer sb = new StringBuffer(word1);
		sb.append(word2);
		System.out.println(sb);
	}
	
	public void removeDuplicates(String word3){
		
		int pos=1;
		char [] characters=word3.toCharArray();
		for(int i=1;i<word3.length();i++){
			int j;
			for(j=0;j<pos;++j){
				if(characters[i]==characters[j]){
					break;
				}
			}
			if(j==pos){
				characters[pos]=characters[i];
				++pos;
			}
			else{
				characters[pos]=0;
				++pos;
			}
			StringBuffer sb=new StringBuffer(characters.length);
			for(char c : characters){
				if(c != 0){
					sb.append(c);
				}
				
			}
			System.out.println("Without duplicates "+sb);
		}
		
	}
	public void oddPosition(String word){
		StringBuffer sb = new StringBuffer(word);
		int count=0;
		for(int i=0;i<sb.length();i++){
			char curchar=sb.charAt(i);
			if(count%2==0){
				sb.setCharAt(i, '#');
			}
			count++;
			System.out.println("Odd position is replaced with #"+sb);
		}
	}
	
	public static void main(String[] args) {
		StringOperator so = new StringOperator();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the word 1 and word 2");
		String word1=sc.next();
		String word2=sc.next();
		so.appendOperation(word1,word2);
		System.out.println("Enter the word 3");
		String word3=sc.next();
		so.removeDuplicates(word3);
		so.oddPosition(word3);
		sc.close();	
	}

}
