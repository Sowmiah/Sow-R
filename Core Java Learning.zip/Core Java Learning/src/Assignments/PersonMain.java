package Assignments;

public class PersonMain extends Person {
	public static void main(String[] args)
	{
		Person p = new Person("Divya","Bharathi","F");
		System.out.println("Person Details");
		System.out.println("_______________");
		//System.out.println("\n");
		System.out.println("FirstName= "+p.firstName);
		System.out.println("LastName= "+p.lastName);
		System.out.println("Gender= "+p.gender);
	}

}

