package Assignments;

public class ModifiedPersonDeatils extends ModifiedPerson {
	public static void main(String[] args)
	{
		ModifiedPerson p = new ModifiedPerson("Divya","Bharathi","F","8876876543",Gender.M);
		System.out.println("Person Details");
		System.out.println("_______________");
		//System.out.println("\n");
		System.out.println("FirstName= "+p.firstName);
		System.out.println("LastName= "+p.lastName);
		//System.out.println("Gender= "+p.gender);
		if(p.acceptPhno("8876876543"))
		{
		System.out.println("Phone Number= "+p.phoneNumber);
		}
		else
			System.out.println("Invalid Phone Number");
		//p.checkGender(Gender.F);
		System.out.println("Gender: "+p.gen);
		
		
	}
}
