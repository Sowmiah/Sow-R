package com.test;

import java.io.IOException;
import java.io.PrintWriter;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;






import javax.annotation.Resource;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class TestDataSources
 * 
 */
@WebServlet("/TestDataSources")
public class TestDataSources extends HttpServlet {
	private static final long serialVersionUID = 1L;
       @Resource(lookup="java:/OracleDS")
	DataSource ds;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestDataSources() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try {
			/*InitialContext ic=new InitialContext();
			DataSource ds=(DataSource)ic.lookup("java:/OracleDS");*/
			Connection con = ds.getConnection();
			
			Statement stmt=con.createStatement();
			ResultSet rst=stmt.executeQuery("select * from emp_tbl");
			out.println("<table border=1><th>EmployeeID</th> <th>EmployeeName</th> <th>EmployeeSalary</th>");
			
			while(rst.next()){
				//out.println("<h1><bold><center><table border>Employee ID Employee Name Employee Salary</table border></center></h1>");
				out.println("<h2><tr><td> "+rst.getInt(1)+" </td><td> "+rst.getString(2)+" </td><td> "+rst.getInt(3)+" </td></tr></h2>");
			}
			
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
