package com.ems.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ems.bean.TrainBean;
import com.ems.exception.TrainException;
import com.ems.service.ITrainService;
import com.ems.service.TrainServiceImpl;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("*.obj")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String path=request.getServletPath().trim();
		ITrainService service=new TrainServiceImpl();
		String target="";
		
		switch(path)
		{
		case "/show.obj" : 
			System.out.println("Into the show.obj");
			String id=request.getParameter("tid");
			try {
				TrainBean bean=service.getTrainDetail(id);
				if(bean!=null){
					request.setAttribute("bean", bean);
					target="ShowTrain.jsp";
				}
				else
				{
				request.setAttribute("message", "ID NOT FOUND");
				target="error.jsp";
				}
			} catch (TrainException e1) {
				request.setAttribute("message", "Exception ="+e1.getMessage());
				target="error.jsp";
			}
			//target="/ShowTrainInfo";
			break;
			
		case "/add.obj" : target="add.html" ; break;
		case "/update.obj" : target="update.html" ; break;
		case "/delete.obj" : target="delete.html" ; break;
		case "/view.obj" :
			try {
				
				List<TrainBean> list=service.viewAllTrains();
				if(list.isEmpty())
				{
					
					target="error1.html";
				}
				else
				{
					request.setAttribute("list", list);
					target="viewAllTrainInfo.jsp";
				}
			} catch (TrainException e) 
			{
				
				target="error1.html";
			}
				//target="view.html" ;
				break;
		case "/home.obj" : target="index.html" ;
		break;
		
		/*case "/add.obj" : message=" ADD SUCCESS" ; break;
		case "/update.obj" : message=" UPDATE SUCCESS" ; break;
		case "/delete.obj" : message=" DELETE SUCCESS" ; break;
		case "/view.obj" : message=" VIEW SUCCESS" ;break;*/
		}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
