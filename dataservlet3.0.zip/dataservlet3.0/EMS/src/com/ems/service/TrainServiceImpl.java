package com.ems.service;

import java.util.List;

import com.ems.bean.TrainBean;
import com.ems.dao.ITrainDao;
import com.ems.dao.TrainDaoImpl;
import com.ems.exception.TrainException;

public class TrainServiceImpl implements ITrainService{

	private ITrainDao dao=new TrainDaoImpl();
	@Override
	public List<TrainBean> viewAllTrains() throws TrainException {
		
		return dao.viewAllTrains();
	}
	@Override
	public TrainBean getTrainDetail(String id) throws TrainException {
		
		return dao.getTrainDetail(id);
	}

}
