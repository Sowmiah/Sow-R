package com.ems.dao;

public interface QueryMapper {
public static final String SELECT_QUERY="select trainid,trainname,destination,departdate,seats,fare from traindetails";
public static final String SELECT_BY_ID="select trainid,trainname,destination from traindetails where trainid=?";
}
