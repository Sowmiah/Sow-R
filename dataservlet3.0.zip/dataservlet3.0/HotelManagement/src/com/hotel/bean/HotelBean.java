package com.hotel.bean;

public class HotelBean {
	
	private int hotelId;
	private String hotelName;
	private String hotelLocation;
	private String hotelEmail;
	private String hotelContactno;
	private char hotelRegister;
	public HotelBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public HotelBean(int hotelId, String hotelName, String hotelLocation,
			String hotelEmail, String hotelContactno, char hotelRegister) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.hotelLocation = hotelLocation;
		this.hotelEmail = hotelEmail;
		this.hotelContactno = hotelContactno;
		this.hotelRegister = hotelRegister;
	}
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getHotelLocation() {
		return hotelLocation;
	}
	public void setHotelLocation(String hotelLocation) {
		this.hotelLocation = hotelLocation;
	}
	public String getHotelEmail() {
		return hotelEmail;
	}
	public void setHotelEmail(String hotelEmail) {
		this.hotelEmail = hotelEmail;
	}
	public String getHotelContactno() {
		return hotelContactno;
	}
	public void setHotelContactno(String hotelContactno) {
		this.hotelContactno = hotelContactno;
	}
	public char getHotelRegister() {
		return hotelRegister;
	}
	public void setHotelRegister(char hotelRegister) {
		this.hotelRegister = hotelRegister;
	}
	@Override
	public String toString() {
		return "HotelBean [hotelId=" + hotelId + ", hotelName=" + hotelName
				+ ", hotelLocation=" + hotelLocation + ", hotelEmail="
				+ hotelEmail + ", hotelContactno=" + hotelContactno
				+ ", hotelRegister=" + hotelRegister + "]";
	}
	
	
	
}
