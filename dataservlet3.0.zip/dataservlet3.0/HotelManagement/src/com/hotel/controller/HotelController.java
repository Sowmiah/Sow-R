package com.hotel.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.bean.HotelBean;
import com.hotel.exception.HotelException;
import com.hotel.service.HotelServiceImpl;
import com.hotel.service.IHotelService;

/**
 * Servlet implementation class HotelController
 */
@WebServlet("*.obj")
public class HotelController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HotelController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		HotelBean bean=new HotelBean();
		IHotelService service=new HotelServiceImpl();
		String path=request.getServletPath().trim();
		String target="";
		System.out.println("outside case");
		switch(path){
		
		case "/home.obj":
			System.out.println("into home");
			target="/home.jsp";
			
			break;
		case "/register.obj":
			System.out.println(" into register");
			target="/register.jsp";
			
			break;
		case "/registered.obj":
			System.out.println("into registered obj");	
			
			
			String hotelName=request.getParameter("hotelName");
			String hotelLocation=request.getParameter("hotelLocation");
			String email=request.getParameter("email");
			String contactNo=request.getParameter("contactNo");
			session.setAttribute("email", email);
			bean.setHotelName(hotelName);
			bean.setHotelLocation(hotelLocation);
			bean.setHotelEmail(email);
			
			bean.setHotelContactno(contactNo);
			char register='N';
			bean.setHotelRegister(register);
			try {
				int id=service.registerHotel(bean);
				if(id>0){
					System.out.println(id);
					
					session.setAttribute("hotel_ID", id);
					Random rd=new Random();
					int num=rd.nextInt(1000)+100;
					session.setAttribute("otp", num);
					target="/success.jsp";
				}
				else{
					target="/failed.jsp";
				}
			} catch (HotelException e) {
				System.out.println("Exception thrown "+e.getMessage());
				session.setAttribute("exception", e.getMessage());
				target="/exception.jsp";
			}
			
			break;
		case "/activate.obj":
			target="/activate.jsp";
			break;
		case "/verifyotp.obj":
			System.out.println("Enters into the verify otp");
			String mail=request.getParameter("email");
			String gotp=request.getParameter("otp");
			String oneTimePass=String.valueOf(session.getAttribute("otp"));
			if(session.getAttribute("email").equals(mail) && oneTimePass.equals(gotp))
			{
				try {
					boolean flag=service.updateHotel(mail);
					if(flag==true){
					session.getAttribute("hotel_ID");
					/*Date regDate=new Date();
					//String cdate=LocalDate.now().toString();
					String rDate=regDate.toString();*/
					
					SimpleDateFormat date= new SimpleDateFormat("dd-MM-yyyy");
					String rDate=date.format(new Date());
					session.setAttribute("regDate",rDate);
					target="/activateSuccess.jsp";
					}
					else{
						System.out.println("Update failed");
						target="error.jsp";
					}
				} catch (HotelException e) {
					session.setAttribute("exception", e.getMessage());
					target="exception.jsp";
				}
			}
			else
			{
				target="/error.jsp";
			}
			
			break;
		case "/view.obj":
			try {
				List<HotelBean> hotelBean=service.viewAllHotels();
				session.setAttribute("hotelBean", hotelBean);
				target="/view.jsp";
			} catch (HotelException e) {
				System.out.println("into view exception");
				session.setAttribute("exception", e.getMessage());
				target="exception.jsp";
			}
			
			break;
		case "/find.obj":
			target="find.jsp";

			break;
		case "/findid.obj":
			try {
				int hotelId=Integer.parseInt(request.getParameter("hotelId"));
				bean=service.findByHotel(hotelId);
				session.setAttribute("bean", bean);
				target="viewFind.jsp";
			} catch (HotelException e) {
				session.setAttribute("exception", e.getMessage());
				target="exception.jsp";
			}
				break;
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

}
