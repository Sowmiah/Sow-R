package com.hotel.service;

import java.util.List;

import com.hotel.bean.HotelBean;
import com.hotel.exception.HotelException;

public interface IHotelService {
	public int registerHotel(HotelBean bean) throws HotelException;
	public boolean updateHotel(String mail) throws HotelException;
	public List<HotelBean> viewAllHotels() throws HotelException;
	public HotelBean findByHotel(int hotelId) throws HotelException;
}
