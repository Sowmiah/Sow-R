package com.hotel.service;

import java.util.List;

import com.hotel.bean.HotelBean;
import com.hotel.dao.HotelDaoImpl;
import com.hotel.dao.IHotelDao;
import com.hotel.exception.HotelException;

public class HotelServiceImpl implements IHotelService{

	IHotelDao dao=new HotelDaoImpl();
	@Override
	public int registerHotel(HotelBean bean) throws HotelException {
		
		return dao.registerHotel(bean);
	}
	@Override
	public boolean updateHotel(String mail) throws HotelException {
		
		return dao.updateHotel(mail);
	}
	@Override
	public List<HotelBean> viewAllHotels() throws HotelException {
		
		return dao.viewAllHotels();
	}
	@Override
	public HotelBean findByHotel(int hotelId) throws HotelException {
		
		return dao.findByHotel(hotelId);
	}
	
}
