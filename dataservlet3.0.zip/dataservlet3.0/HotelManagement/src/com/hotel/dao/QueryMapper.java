package com.hotel.dao;

public interface QueryMapper {
	
	public static final String INSERT_QUERY="insert into hotel_tbl values (hotel_seq.nextval,?,?,?,?,?)";
	public static final String SEQ_QUERY="select hotel_seq.currval from hotel_tbl";
	public static final String UPDATE_QUERY="update hotel_tbl set hotel_register='Y' where hotel_email=?";
	public static final String VIEW_QUERY="select hotel_id,hotel_name,hotel_location,hotel_email,hotel_contactno,hotel_register from hotel_tbl";
	public static final String FIND_BY_ID_QUERY="select hotel_id,hotel_name,hotel_location,hotel_email,hotel_contactno,hotel_register from hotel_tbl where hotel_id=?";
}
