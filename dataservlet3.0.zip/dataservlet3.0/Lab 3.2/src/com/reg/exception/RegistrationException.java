package com.reg.exception;

public class RegistrationException extends Exception{

	public RegistrationException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
