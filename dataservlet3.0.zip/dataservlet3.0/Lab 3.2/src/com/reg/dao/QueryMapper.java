package com.reg.dao;

public interface QueryMapper {
	public static final String INSERT_QUERY="insert into RegisteredUsers (firstname,lastname,password,gender,skillset,city) values (?,?,?,?,?,?)";
	public static final String SELECT_QUERY="select firstname,lastname,password,gender,skillset,city from RegisteredUsers";
}
