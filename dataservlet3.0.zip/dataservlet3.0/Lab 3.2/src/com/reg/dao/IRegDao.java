package com.reg.dao;

import java.util.List;

import com.reg.bean.RegistrationBean;
import com.reg.exception.RegistrationException;

public interface IRegDao {
	public int addRegistrationUsers(RegistrationBean bean)
			throws RegistrationException;
	public List<RegistrationBean> viewAllRegDetails() throws RegistrationException;
}
