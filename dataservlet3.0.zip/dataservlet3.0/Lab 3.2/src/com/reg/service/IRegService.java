package com.reg.service;

import java.util.List;

import com.reg.bean.RegistrationBean;
import com.reg.exception.RegistrationException;

public interface IRegService {

	public int addRegistrationUsers(RegistrationBean bean) throws RegistrationException;
	public List<RegistrationBean> viewAllRegDetails() throws RegistrationException;
}
