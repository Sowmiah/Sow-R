package com.reg.service;

import java.util.List;

import com.reg.bean.RegistrationBean;
import com.reg.dao.IRegDao;
import com.reg.dao.RegDaoImpl;
import com.reg.exception.RegistrationException;


public class RegServiceImpl implements IRegService {
	IRegDao regDao=new RegDaoImpl();
	@Override
	public int addRegistrationUsers(RegistrationBean bean)
			throws RegistrationException {
		
		return regDao.addRegistrationUsers(bean);
	}
	@Override
	public List<RegistrationBean> viewAllRegDetails()
			throws RegistrationException {
		
		return regDao.viewAllRegDetails();
	}

	
}
