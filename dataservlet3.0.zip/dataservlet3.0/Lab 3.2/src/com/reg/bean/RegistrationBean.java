package com.reg.bean;

public class RegistrationBean {
	private String firstName;
	private String lastName;
	private String password;
	private char gender;
	private String skillset;
	private String city;
	
	public RegistrationBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public RegistrationBean(String firstName, String lastName, String password,
			char gender, String skillset, String city) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.gender = gender;
		this.skillset = skillset;
		this.city = city;
	}


	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getSkillset() {
		return skillset;
	}

	public void setSkillset(String skillset) {
		this.skillset = skillset;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}



	@Override
	public String toString() {
		return "RegistraionBean [firstName=" + firstName + ", lastName="
				+ lastName + ", gender=" + gender + ", skillset=" + skillset
				+ ", city=" + city + "]";
	}
}
