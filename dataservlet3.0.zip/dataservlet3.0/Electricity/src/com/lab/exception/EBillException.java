package com.lab.exception;

public class EBillException extends Exception {

	public EBillException(String msg) {
		super(msg);
		
	}

	
}
