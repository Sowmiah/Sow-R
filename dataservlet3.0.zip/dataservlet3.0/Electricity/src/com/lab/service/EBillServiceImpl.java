package com.lab.service;

import com.lab.bean.BillDetailsBean;
import com.lab.bean.ConsumerBean;
import com.lab.dao.EBILLDAOImpl;
import com.lab.dao.EBillDAO;
import com.lab.exception.EBillException;

public class EBillServiceImpl implements EBIllService {

	EBillDAO dao=new EBILLDAOImpl();
	@Override
	public ConsumerBean retrieveConsNum(int num) throws EBillException {
		
		return dao.retrieveConsNum(num);
	}
	@Override
	public int inserBill(BillDetailsBean billBean) throws EBillException {
		
		return dao.inserBill(billBean);
	}
	

}
