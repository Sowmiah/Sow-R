package com.lab.service;

import com.lab.bean.BillDetailsBean;
import com.lab.bean.ConsumerBean;
import com.lab.exception.EBillException;

public interface EBIllService {

	public ConsumerBean retrieveConsNum(int num) throws EBillException;
	public int inserBill(BillDetailsBean billBean) throws EBillException;
}
