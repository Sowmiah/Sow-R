package com.lab.bean;

import java.util.Date;

public class BillDetailsBean {

	private int billNum;
	private int consumerNum;
	private double curRading;
	private double unitConsumed;
	private double netAmount;
	private Date billDate;
	public BillDetailsBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BillDetailsBean(int billNum, int consumerNum, double curRading,
			double unitConsumed, double netAmount, Date billDate) {
		super();
		this.billNum = billNum;
		this.consumerNum = consumerNum;
		this.curRading = curRading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.billDate = billDate;
	}
	public int getBillNum() {
		return billNum;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	public int getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}
	public double getCurRading() {
		return curRading;
	}
	public void setCurRading(double curRading) {
		this.curRading = curRading;
	}
	public double getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public Date getBillDate() {
		return billDate;
	}
	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}

	
	
}
