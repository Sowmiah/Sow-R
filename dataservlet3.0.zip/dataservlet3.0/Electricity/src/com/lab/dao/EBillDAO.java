package com.lab.dao;

import com.lab.bean.BillDetailsBean;
import com.lab.bean.ConsumerBean;
import com.lab.exception.EBillException;

public interface EBillDAO {
	public ConsumerBean retrieveConsNum(int num) throws EBillException;
	public int inserBill(BillDetailsBean billBean) throws EBillException;
}
