package com.lab.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lab.bean.BillDetailsBean;
import com.lab.bean.ConsumerBean;
import com.lab.exception.EBillException;
import com.lab.util.DBConnection;

public class EBILLDAOImpl implements EBillDAO{
java.sql.Date billDate=new Date(new java.util.Date().getTime());
	@Override
	public ConsumerBean retrieveConsNum(int num) throws EBillException {
		ConsumerBean bean=new ConsumerBean();
		try {
			Connection con=DBConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.SELECT_QUERY);
			pstmt.setInt(1, num);
			ResultSet rst=pstmt.executeQuery();
			if(rst.next()){
				bean.setConsumerNo(rst.getInt("consumer_num"));
				bean.setConsumerName(rst.getString("consumer_name"));
			}
			con.close();
		} catch (SQLException e) {
			throw new EBillException("Consumer number not found");
		}
		return bean;
	}
	public int inserBill(BillDetailsBean billBean) throws EBillException {
	int id=0;
	try {
		Connection con=DBConnection.getConnection();
		String qry=QueryMapper.INSERT_QUERY;
		PreparedStatement pstmt=con.prepareStatement(qry); 
		pstmt.setInt(1, billBean.getConsumerNum());
		pstmt.setDouble(2, billBean.getCurRading());
		pstmt.setDouble(3, billBean.getUnitConsumed());
		pstmt.setDouble(4, billBean.getNetAmount());
		pstmt.setDate(5, billDate);
		int count = pstmt.executeUpdate();
		if(count <= 0){
			throw new EBillException("INSERT FAIL");
		}
		qry=QueryMapper.SEQ_QUERY;
		pstmt=con.prepareStatement(qry);
		ResultSet rst=pstmt.executeQuery();
		if(rst.next()){
			id=rst.getInt(1);
		}
		else{
			throw new EBillException("UNABLE TO READ FROM SEQ");
		}
	} catch (SQLException e) {

		throw new EBillException("SQL EXCEPTION:"+e.getMessage());
	}
	return(id);	
	}

	

}
