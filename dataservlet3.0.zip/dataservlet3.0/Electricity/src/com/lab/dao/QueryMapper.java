package com.lab.dao;

public interface QueryMapper {
public static final String SELECT_QUERY="select consumer_num,consumer_name from Consumers where consumer_num=?";
public static final String INSERT_QUERY="insert into BillDetails values (bill_seq.nextval,?,?,?,?,?)";
public static final String SEQ_QUERY="select bill_seq.currval from BillDetails";
public static final String VIEW_QUERY="select consumer_num,consumer_name,address from consumers";
}
