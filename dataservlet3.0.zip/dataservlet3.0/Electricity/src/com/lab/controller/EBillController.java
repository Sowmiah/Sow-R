package com.lab.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lab.bean.BillDetailsBean;
import com.lab.bean.ConsumerBean;
import com.lab.exception.EBillException;
import com.lab.service.EBIllService;
import com.lab.service.EBillServiceImpl;

/**
 * Servlet implementation class EBillController
 */
@WebServlet("*.obj")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String path=request.getServletPath().trim();
		String target="";
		switch(path){
		case "/login.obj":
			System.out.println("Enter into login");
			String username=request.getParameter("user");
			String password=request.getParameter("pass");
			if(username.equals("user") && password.equals("user123")){
				target="userinfo.html";
			}
			else
				target="error.html";
			
			break;
		case "/cal.obj":
			System.out.println("Enters into calculate");
			EBIllService service=new EBillServiceImpl();
			HttpSession session = request.getSession(true);
			int consumerNumber=Integer.parseInt(request.getParameter("consumerNo"));
			try {
				System.out.println("Enters into calculate tru block");
				ConsumerBean bean=service.retrieveConsNum(consumerNumber);
				BillDetailsBean billBean=new BillDetailsBean();
				if(bean.getConsumerNo()==(consumerNumber))
				{
					System.out.println("Consumer no. is equal");
					int fixedCharge=100;
					double lastReading=Double.parseDouble(request.getParameter("lastmonth"));
					double currReading=Double.parseDouble(request.getParameter("currmonth"));
					double units=lastReading-currReading;
					double netAmt=units*1.15+fixedCharge;
					billBean.setConsumerNum(consumerNumber);
					billBean.setCurRading(currReading);
					billBean.setUnitConsumed(units);
					billBean.setNetAmount(netAmt);
					int num=service.inserBill(billBean);
					if(num>0){
						session.setAttribute("name",bean.getConsumerName());
						session.setAttribute("consumerNumber", billBean.getConsumerNum());
						session.setAttribute("units", billBean.getUnitConsumed());
						session.setAttribute("netAmt", billBean.getNetAmount());
						target="welcome.jsp";
					}
					else{
						System.out.println("insertion failed");
						target="error.html";
					}
					
				}
				else{
					System.out.println("consumer number varies");
					target="invalidateConsumerNo.html";
				}
			} catch (NumberFormatException e) {
				System.out.println("Number format Exception occured");
				target="error1.html";
			} catch (EBillException e) {
				System.out.println("EBillException Exception Occured"+e.getMessage());
				target="error1.html";
			}
			
		case "/show.obj":
			break;
		case "/search.obj":
			break;
		}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	
}
