package com.train.bean;

import java.time.LocalDate;
import java.util.Date;

public class TrainBean {
	private String trainId;
	private String trainName;
	private String trainDest;
	private Date trainDept;
	private int trainSeat;
	private Double trainFare;
	
	public TrainBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public TrainBean(String trainId, String trainName, String trainDest,
			Date trainDept, int trainSeat, Double trainFare) {
		super();
		this.trainId = trainId;
		this.trainName = trainName;
		this.trainDest = trainDest;
		this.trainDept = trainDept;
		this.trainSeat = trainSeat;
		this.trainFare = trainFare;
	}

	public String getTrainId() {
		return trainId;
	}
	public void setTrainId(String trainId) {
		this.trainId = trainId;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
	public String getTrainDest() {
		return trainDest;
	}
	public void setTrainDest(String trainDest) {
		this.trainDest = trainDest;
	}
	public Date getTrainDept() {
		return trainDept;
	}
	public void setTrainDept(Date trainDept) {
		this.trainDept = trainDept;
	}
	public int getTrainSeat() {
		return trainSeat;
	}
	public void setTrainSeat(int trainSeat) {
		this.trainSeat = trainSeat;
	}
	public Double getTrainFare() {
		return trainFare;
	}
	public void setTrainFare(Double trainFare) {
		this.trainFare = trainFare;
	} 
}
