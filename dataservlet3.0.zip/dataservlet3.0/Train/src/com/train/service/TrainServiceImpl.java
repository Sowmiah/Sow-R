package com.train.service;

import java.util.List;

import com.train.bean.TrainBean;
import com.train.dao.ITrainDao;
import com.train.dao.TrainDaoImpl;
import com.train.exception.TrainException;



public class TrainServiceImpl implements ITrainService{
	private ITrainDao dao=new TrainDaoImpl();
	@Override
	public List<TrainBean> viewAllTrains() throws TrainException {
		
		return dao.viewAllTrains();
	}
	@Override
	public TrainBean getTrainDetail(String id) throws TrainException {
		
		return dao.getTrainDetail(id);
	}
	@Override
	public boolean bookTrain(String id, int seats) throws TrainException {
		// TODO Auto-generated method stub
		return false;
	}
}
