package com.train.service;

import java.util.List;

import com.train.bean.TrainBean;
import com.train.exception.TrainException;



public interface ITrainService {
	public List<TrainBean> viewAllTrains() throws TrainException;
	public TrainBean getTrainDetail(String id) throws TrainException;
	public boolean bookTrain(String id,int seats) throws TrainException;
}
