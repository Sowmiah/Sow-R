package com.train.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.train.bean.TrainBean;
import com.train.exception.TrainException;
import com.train.service.ITrainService;
import com.train.service.TrainServiceImpl;



/**
 * Servlet implementation class TrainController
 */
@WebServlet("*.obj")
public class TrainController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TrainController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String path=request.getServletPath().trim();
		ITrainService service=new TrainServiceImpl();
		String target="";
		System.out.println("outside case");
		switch(path)
		{
		case "/show.obj" : 
		{
			System.out.println("Into the show.obj");
			String id=request.getParameter("tid");
			try {
				TrainBean bean=service.getTrainDetail(id);
				if(bean!=null){
					request.setAttribute("bean", bean);
					target="showTrainInfo.jsp";
				}
				else
				{
				request.setAttribute("message", "ID NOT FOUND");
				target="error.jsp";
				}
			} catch (TrainException e1) {
				request.setAttribute("message", "Exception ="+e1.getMessage());
				target="error.jsp";
			}
			//target="/ShowTrainInfo";
			break;
		}
		case "/add.obj" :
			System.out.println("inside add.obj");
			target="add.html";
		break;
		
		case "/update.obj" : target="update.html" ; break;
		case "/delete.obj" : target="delete.html" ; break;
		case "/view.obj" :
			try {
				
				List<TrainBean> list=service.viewAllTrains();
				System.out.println(" inside controller ");
				System.out.println(list.size());
				if(list.isEmpty())
				{
					
					target="error.html";
				}
				else
				{
					request.setAttribute("list", list);
					System.out.println("Enters into view");
					target="viewAllTrainDetails.jsp";
				}
			} catch (TrainException e) 
			{
				System.out.println(" Message =  "+e.getMessage());
				target="error1.html";
			}
				//target="view.html" ;
				break;
		case "/home.obj" : target="index.html" ;
		break;
		
		/*case "/add.obj" : message=" ADD SUCCESS" ; break;
		case "/update.obj" : message=" UPDATE SUCCESS" ; break;
		case "/delete.obj" : message=" DELETE SUCCESS" ; break;
		case "/view.obj" : message=" VIEW SUCCESS" ;break;*/
		}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
