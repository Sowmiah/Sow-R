package com.train.exception;

public class TrainException extends Exception{

	public TrainException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	

}
