package com.train.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;




import com.train.bean.TrainBean;
import com.train.exception.TrainException;
import com.train.util.DBConnection;

public class TrainDaoImpl implements ITrainDao {

	@Override
	public List<TrainBean> viewAllTrains() throws TrainException {
		System.out.println(" inside dao ");
		List<TrainBean> list=new ArrayList<TrainBean>();
		try {
			Connection con=DBConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.SELECT_QUERY);
			ResultSet rst=pstmt.executeQuery();
			while(rst.next())
			{
				TrainBean bean=new TrainBean();
				bean.setTrainId(rst.getString("trainid"));
				bean.setTrainName(rst.getString("trainname"));
				bean.setTrainDest(rst.getString("destination"));
				bean.setTrainDept(rst.getDate("departdate"));
				bean.setTrainSeat(rst.getInt("seats"));
				bean.setTrainFare(rst.getDouble("fare"));
				list.add(bean);
			}
			con.close();
			System.out.println(" complete dao");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new TrainException("unable to fetch data"+e.getMessage());
			
		}
		return (list);
	}

	@Override
	public TrainBean getTrainDetail(String id) throws TrainException {
		TrainBean bean=null;
		
		try {
			Connection con=DBConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.SELECT_BY_ID);
			pstmt.setString(1, id);
			ResultSet rst=pstmt.executeQuery();
			if(rst.next()){
				bean=new TrainBean();
				bean.setTrainId(rst.getString("trainid"));
				bean.setTrainName(rst.getString("trainname"));
				bean.setTrainDest(rst.getString("destination"));
			}
			con.close();
		} catch (SQLException e) {
			throw new TrainException("unable to fetch ID "+e.getMessage());
		}
		return bean;
	}

	@Override
	public boolean bookTrain(String id, int seats) throws TrainException {
		
		return false;
	}

	
}
