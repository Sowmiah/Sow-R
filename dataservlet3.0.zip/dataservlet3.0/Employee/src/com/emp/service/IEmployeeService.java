package com.emp.service;

import java.util.List;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface IEmployeeService {

	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	List<EmployeeBean> viewAllEmployee() throws EmployeeException;
}
