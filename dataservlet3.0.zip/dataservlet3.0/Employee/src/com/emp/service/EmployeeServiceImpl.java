package com.emp.service;

import java.util.List;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.dao.IEmployeeDao;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService{

	IEmployeeDao employeeDao = new EmployeeDaoImpl();
	
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id=employeeDao.addEmployee(bean);
		return (id);
	}

	@Override
	public List<EmployeeBean> viewAllEmployee() throws EmployeeException {
		
		return employeeDao.viewAllEmployees();
	}

}
