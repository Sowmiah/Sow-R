package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImpl implements IEmployeeDao{
		
	@Override
	public int addEmployee(EmployeeBean employee) throws EmployeeException {
		
		int id=0;
		
		try {
			
			Connection con=DBConnection.getConnection();
			String qry=QueryMapper.INSERT_QUERY;
			PreparedStatement pstmt=con.prepareStatement(qry); 
			pstmt.setString(1,employee.getEmpName());
			pstmt.setDouble(2,employee.getSalary());
			int count = pstmt.executeUpdate();
			if(count <= 0){
				
				throw new EmployeeException("INSERT FAIL");
			}
			qry=QueryMapper.SELECT_ID_QUERY;
			pstmt=con.prepareStatement(qry);
			ResultSet rst=pstmt.executeQuery();
			if(rst.next()){
				id=rst.getInt(1);
			}
			else{
				
				throw new EmployeeException("UNABLE TO READ FROM SEQ");
			}
		} catch (SQLException e) {

			throw new EmployeeException(e.getMessage());
		}
		return(id);	
	}

	@Override
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException {
		List<EmployeeBean> list=new ArrayList<EmployeeBean>();
		try {
			Connection con=DBConnection.getConnection();
			String qry=QueryMapper.SELECT_ALL_EMP_QUERY;
			PreparedStatement pstmt=con.prepareStatement(qry);
			ResultSet rst=pstmt.executeQuery();
			while(rst.next()){
				EmployeeBean bean=new EmployeeBean();
				
				bean.setEmpId(rst.getInt("empid"));
				bean.setEmpName(rst.getString("empname"));
				bean.setSalary(rst.getDouble("empsalary"));
				
				list.add(bean);
			}
			con.close();
		} catch (SQLException e) {
			throw new EmployeeException("EXCEPTION IN VIEW ALL EMPLOYEES"+e.getMessage());
		}
		return list;
	}
}
