package com.reg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import java.util.ArrayList;
import java.util.List;

import com.reg.bean.RegistrationBean;
import com.reg.exception.RegistrationException;
import com.reg.util.DBConnection;

public class RegDaoImpl implements IRegDao{

	@Override
	public int addRegistrationUsers(RegistrationBean bean)
			throws RegistrationException {

		int count=0;
		try {
			
			Connection con=DBConnection.getConnection();
			String qry=QueryMapper.INSERT_QUERY;
			PreparedStatement pstmt=con.prepareStatement(qry); 
			pstmt.setString(1,bean.getFirstName());
			pstmt.setString(2, bean.getLastName());
			pstmt.setString(3, bean.getPassword());
			pstmt.setString(4, String.valueOf(bean.getGender()));
			pstmt.setString(5, bean.getSkillset());
			pstmt.setString(6, bean.getCity());
			count = pstmt.executeUpdate();
			if(count <= 0){
				
				throw new RegistrationException("INSERT FAIL");
			}
			
			
		} catch (SQLException e) {

			throw new RegistrationException(e.getMessage());
		}
		return(count);
		
	}
	
	@Override
	public List<RegistrationBean> viewAllRegDetails() throws RegistrationException
			 {
		List<RegistrationBean> list=new ArrayList<RegistrationBean>();
		try {
			Connection con=DBConnection.getConnection();
			String qry=QueryMapper.SELECT_QUERY;
			PreparedStatement pstmt=con.prepareStatement(qry);
			ResultSet rst=pstmt.executeQuery();
			while(rst.next()){
				RegistrationBean bean=new RegistrationBean();
				bean.setFirstName(rst.getString("firstname"));
				bean.setLastName(rst.getString("lastname"));
				bean.setPassword(rst.getString("password"));
				char gen=rst.getString("gender").charAt(0);
				bean.setGender(gen);
				bean.setSkillset(rst.getString("skillset"));
				bean.setCity(rst.getString("city"));
				list.add(bean);
			}
			con.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return list;
	
	}

	
}
