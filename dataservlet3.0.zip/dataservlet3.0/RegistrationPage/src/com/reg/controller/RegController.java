package com.reg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.reg.bean.RegistrationBean;
import com.reg.exception.RegistrationException;
import com.reg.service.IRegService;
import com.reg.service.RegServiceImpl;

/**
 * Servlet implementation class RegController
 */
@WebServlet("/RegController")
public class RegController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h1>Registration Details</h1>");
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String password=request.getParameter("pass");
		String gender=request.getParameter("gender");
		char gen=gender.charAt(0);
		String [] skill=request.getParameterValues("skill");
		String city=request.getParameter("city");
		
		RegistrationBean bean=new RegistrationBean();
		bean.setFirstName(fname);
		bean.setLastName(lname);
		bean.setPassword(password);
		bean.setGender(gen);
		String str=" ";
		for(int i=0;i<skill.length;i++){
			skill[i]=skill[i]+str;
			bean.setSkillset(skill[i]);
		}
		bean.setCity(city);
		IRegService regservice=new RegServiceImpl();
		int count=0;
		try {
			count = regservice.addRegistrationUsers(bean);
			
		} catch (RegistrationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(count>0)
		{
			out.println(count+"Row Added Successfully");
			RequestDispatcher rd=getServletContext().getRequestDispatcher("ViewController");
			rd.include(request, response);
		}
				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
