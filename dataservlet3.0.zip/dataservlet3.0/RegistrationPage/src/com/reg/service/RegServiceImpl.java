package com.reg.service;

import java.util.List;

import com.reg.bean.RegistrationBean;
import com.reg.dao.IRegDao;
import com.reg.dao.RegDaoImpl;
import com.reg.exception.RegistrationException;

public class RegServiceImpl implements IRegService {

	IRegDao regdao = new RegDaoImpl();
	@Override
	public int addRegistrationUsers(RegistrationBean bean)
			throws RegistrationException {
		
		return regdao.addRegistrationUsers(bean);
	}
	@Override
	public List<RegistrationBean> viewAllRegDetails()
			throws RegistrationException {
		
		return regdao.viewAllRegDetails();
	}

}
