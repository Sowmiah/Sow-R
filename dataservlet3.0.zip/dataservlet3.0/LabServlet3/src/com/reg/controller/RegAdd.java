package com.reg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.reg.bean.RegBean;
import com.reg.exception.RegException;
import com.reg.service.IRegService;
import com.reg.service.RegServiceImpl;

/**
 * Servlet implementation class RegAdd
 */
@WebServlet("/RegAdd")
public class RegAdd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegAdd() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		RegBean bean=new RegBean();
		IRegService ser = new RegServiceImpl();
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h1> Registration Details </h1>");
		String firstname=request.getParameter("firstname");
		String lastname=request.getParameter("lastname");
		String password=request.getParameter("password");
		String gender=request.getParameter("gender");
		char gen=gender.charAt(0);
		String[] skillset=request.getParameterValues("skillset");
		String city=request.getParameter("city");
		bean.setFirstname(firstname);
		bean.setLastname(lastname);
		bean.setPassword(password);
		bean.setGender(gen);
		String str="";
		for(int i=0;i<skillset.length;i++)
			{
			str=skillset[i]+str;
			}
		bean.setSkillset(str);
		bean.setCity(city);	
		try {
			int id=ser.addPer(bean);
			if(id>0)
			{
		           out.println("Registration done!!!");
				/*response.sendRedirect("success.html");*/
				RequestDispatcher rd=getServletContext().getRequestDispatcher("/RegView");
				rd.include(request, response);
				
				
			}
			else
//				out.println("Registration failed!!!");
				response.sendRedirect("failure.html");
		} catch (RegException e) {
	         out.println(e.getMessage());
		}
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	
	}


	}


