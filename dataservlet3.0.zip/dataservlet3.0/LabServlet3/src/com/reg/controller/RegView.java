package com.reg.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.reg.bean.RegBean;
import com.reg.exception.RegException;
import com.reg.service.IRegService;
import com.reg.service.RegServiceImpl;

/**
 * Servlet implementation class RegView
 */
@WebServlet("/RegView")
public class RegView extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegView() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*RegBean bean=new RegBean();*/
		IRegService ser = new RegServiceImpl();
		PrintWriter out=response.getWriter();
		try {
			List<RegBean> list=ser.viewAllReg();
			System.out.println(list.size());
			response.setContentType("text/html");
			
			out.println("<h1> REGISTERED DETAILS </h1>");
			out.println("<table border=\"1\" ");
			out.println("<tr><th>FIRST NAME</th><th>SECOND NAME</th><th>PASSWORD</th><th>GENDER</th><th>SKILLSET</th><th>CITY</th></tr>");
			for(RegBean bean1:list)
			{
				out.println("<tr><td>"+bean1.getFirstname()+"</td><td>"+bean1.getLastname()+"</td><td>"+bean1.getPassword()+"</td><td>"+bean1.getGender()+"</td><td>"+bean1.getSkillset()+"</td><td>"+bean1.getCity()+"</td><tr>");
			}
			out.println("</table>");
		} catch (RegException e) {
			out.println(e.getMessage());
		}
	}

	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
