package com.reg.service;

import java.util.List;

import com.reg.bean.RegBean;
import com.reg.dao.IRegDao;
import com.reg.dao.RegDaoImpl;
import com.reg.exception.RegException;

public class RegServiceImpl implements IRegService{

	IRegDao dao=new RegDaoImpl();
	@Override
	public int addPer(RegBean bean) throws RegException {
		int result1 = dao.addPer(bean);
		return result1;
	}
	@Override
	public List<RegBean> viewAllReg() throws RegException {
		// TODO Auto-generated method stub
		return dao.viewAllReg();
	}

}
