package com.reg.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.reg.bean.RegBean;
import com.reg.exception.RegException;
import com.reg.util.DBConnection;

public class RegDaoImpl implements IRegDao {
	
	@Override
	public int addPer(RegBean bean) throws RegException {
		int count=0;
			try {
				Connection con=DBConnection.getConnection();
				String qry=QueryMapper.INSERTQUERY;
				PreparedStatement pstmt=con.prepareStatement(qry);
				pstmt.setString(1, bean.getFirstname());
				pstmt.setString(2, bean.getLastname());
				pstmt.setString(3, bean.getPassword());
				pstmt.setString(4, String.valueOf(bean.getGender()));
				pstmt.setString(5, bean.getSkillset());
				pstmt.setString(6, bean.getCity());
				count=pstmt.executeUpdate();
				if(count<=0)
				{	
					throw new RegException("INSERT FAILED");
				}
				
				con.close();
				
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
			return count;
		}

	@Override
	public List<RegBean> viewAllReg() throws RegException {
		List<RegBean> list=new ArrayList<RegBean>();
		Connection con=DBConnection.getConnection();
		try {
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.VIEWQUERY);
			ResultSet rst=pstmt.executeQuery();
			while(rst.next())
			{
				RegBean bean=new RegBean();
				bean.setFirstname(rst.getString("firstname"));
				bean.setLastname(rst.getString("lastname"));
				bean.setPassword(rst.getString("password"));
				char ch=rst.getString("gender").charAt(0);
				bean.setGender(ch);
				bean.setSkillset(rst.getString("skillset"));
				bean.setCity(rst.getString("city"));
				list.add(bean);		
			}
			
			con.close();
		} catch (SQLException e) {
			
			throw new RegException("unable to retrive"+e.getMessage());
		}
		
		return (list);
	}

	} 
