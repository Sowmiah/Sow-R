package com.reg.dao;

public interface QueryMapper {

	public static final String INSERTQUERY="INSERT INTO RegisteredUsers (firstname,lastname,password,gender,skillset,city) VALUES(?,?,?,?,?,?)";
    public static final String VIEWQUERY="select firstname,lastname,password,gender,skillset,city from registeredusers";
}
