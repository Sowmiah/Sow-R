package com.reg.dao;

import java.util.List;


import com.reg.bean.RegBean;
import com.reg.exception.RegException;

public interface IRegDao {

	public int addPer(RegBean bean) throws RegException;
	public List<RegBean> viewAllReg() throws RegException;
}
