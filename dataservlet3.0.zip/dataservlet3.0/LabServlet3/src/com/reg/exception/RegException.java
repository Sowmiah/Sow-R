package com.reg.exception;

public class RegException extends Exception{
	public RegException(String message)
	{
		super(message);
	}
}



