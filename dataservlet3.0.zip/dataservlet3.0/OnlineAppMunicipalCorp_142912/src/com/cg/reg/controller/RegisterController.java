package com.cg.reg.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.reg.bean.UserBean;
import com.cg.reg.exception.FirmException;
import com.cg.reg.service.RegisterService;
import com.cg.reg.service.RegisterServiceImpl;

/**
 * Servlet implementation class RegisterController
 */
@WebServlet("*.obj")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		RegisterService regService=new RegisterServiceImpl();
		UserBean bean=new UserBean();
		String path=request.getServletPath().trim();
		String target="";
		switch(path)
		{
		case "/home.obj":
			target="/home.jsp";
			break;
		case "/register.obj":
			target="register.jsp";
			break;
		case "/registered.obj":
			String name=request.getParameter("ownerName");
			String bName=request.getParameter("businessName");
			String email=request.getParameter("email");
			String contactNo=request.getParameter("mobileNo");
			
			//Setting the session for Email-ID
			session.setAttribute("email", email);
			
			bean.setOwnerName(name);
			bean.setBusinessName(bName);
			bean.setEmail(email);
			bean.setMobileNo(contactNo);
			char isactive='N';
			bean.setIsactive(isactive);
			
			try {
				int num=regService.registerFirm(bean);
				if(num>0)
				{
					//Activation Code Generation
					Random rd=new Random();
					int code=rd.nextInt(10000)+10000;
					session.setAttribute("activationCode", code);
					target="success.jsp";
				}
				else{
					
					target="insertfailed.jsp";
				}
			} catch (FirmException e) {
				
				session.setAttribute("error", e.getMessage());
				target="errorpage.jsp";
			}
			
			break;
		case "/activate.obj":
			target="activate.jsp";
			break;
		case "/verifycode.obj":
			String mail=request.getParameter("email");
			String acode=request.getParameter("code");
			String activateCode=String.valueOf(session.getAttribute("activationCode"));
			if(session.getAttribute("email").equals(mail) && acode.equals(activateCode))
			{
				try {
					boolean flag=regService.updateRegister(mail);
					if(flag==true)
					{
						//Activation Date and Time 
						SimpleDateFormat date= new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
						String rDate=date.format(new Date());
						session.setAttribute("regDate",rDate);
						target="activated.jsp";
					}
					else{
						
						target="updatefailed.jsp";
					}
				} catch (FirmException e) {
					
					session.setAttribute("error", e.getMessage());
					target="errorpage.jsp";
				}
			}
			else{
				target="verifyfailed.jsp";
			}
			break;
		
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
