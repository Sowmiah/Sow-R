package com.cg.reg.dao;

import com.cg.reg.bean.UserBean;
import com.cg.reg.exception.FirmException;




public interface RegisterDAO {
	public int registerFirm(UserBean bean) throws FirmException;
	public boolean updateRegister(String email) throws FirmException;
}
