package com.cg.reg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.reg.bean.UserBean;
import com.cg.reg.exception.FirmException;
import com.cg.reg.util.DBConnection;



public class RegisterDAOImpl implements RegisterDAO{

	@Override
	public int registerFirm(UserBean bean) throws FirmException {
		int id=0;
		try {
			Connection con=DBConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.INSERT_QUERY);
			pstmt.setString(1,bean.getOwnerName());
			pstmt.setString(2,bean.getBusinessName());
			pstmt.setString(3, bean.getEmail());
			pstmt.setString(4, bean.getMobileNo());
			String active=String.valueOf(bean.getIsactive());
			pstmt.setString(5,active);
			int count=pstmt.executeUpdate();
			if(count<0){
				throw new FirmException("Add hotel failed ");
			}
			String qry=QueryMapper.SEQ_QUERY;
			pstmt=con.prepareStatement(qry);
			ResultSet rst=pstmt.executeQuery();
			if(rst.next())
			{
				id=rst.getInt(1);
			}
			else
			{
				throw new FirmException("Sequence not generated correctly");
			}
		} catch (SQLException e) {
			throw new FirmException ("SQL Exception has occured"+e.getMessage());
		}
		return(id);
	}

	@Override
	public boolean updateRegister(String email) throws FirmException {
		boolean flag=false;
		try {
			Connection con=DBConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.UPDATE_QUERY);
			pstmt.setString(1,email);
			int count=pstmt.executeUpdate();
			if(count>0){
				System.out.println("update Successfull");
				flag=true;
			}
			else{
				flag=false;
			}
		} catch (SQLException e) {
			throw new FirmException("SQL Exception update failed");
		}
		return flag;
	}

}
