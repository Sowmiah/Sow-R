package com.cg.reg.dao;

public interface QueryMapper {
	public static final String INSERT_QUERY="insert into firms_master values (seq_firm_master.nextval,?,?,?,?,?)";
	public static final String SEQ_QUERY="select seq_firm_master.currval from firms_master";
	public static final String UPDATE_QUERY="update firms_master set isactive='Y' where email=?";
}
