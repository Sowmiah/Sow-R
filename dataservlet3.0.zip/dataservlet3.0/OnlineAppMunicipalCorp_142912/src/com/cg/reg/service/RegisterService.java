package com.cg.reg.service;

import com.cg.reg.bean.UserBean;
import com.cg.reg.exception.FirmException;

public interface RegisterService {
	public int registerFirm(UserBean bean) throws FirmException;
	public boolean updateRegister(String email) throws FirmException;
}
