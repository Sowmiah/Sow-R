package com.cg.reg.service;

import com.cg.reg.bean.UserBean;
import com.cg.reg.dao.RegisterDAO;
import com.cg.reg.dao.RegisterDAOImpl;
import com.cg.reg.exception.FirmException;

public class RegisterServiceImpl implements RegisterService {

	RegisterDAO dao=new RegisterDAOImpl();
	@Override
	public int registerFirm(UserBean bean) throws FirmException {
		
		return dao.registerFirm(bean);
	}

	@Override
	public boolean updateRegister(String email) throws FirmException {
		
		return dao.updateRegister(email);
	}

}
