package com.cg.reg.bean;

public class UserBean {

	private int firmId;
	private String ownerName;
	private String businessName;
	private String email;
	private String mobileNo;
	private char isactive;
	public UserBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserBean(int firmId, String ownerName, String businessName,
			String email, String mobileNo, char isactive) {
		super();
		this.firmId = firmId;
		this.ownerName = ownerName;
		this.businessName = businessName;
		this.email = email;
		this.mobileNo = mobileNo;
		this.isactive = isactive;
	}
	public int getFirmId() {
		return firmId;
	}
	public void setFirmId(int firmId) {
		this.firmId = firmId;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public char getIsactive() {
		return isactive;
	}
	public void setIsactive(char isactive) {
		this.isactive = isactive;
	}
	@Override
	public String toString() {
		return "UserBean [firmId=" + firmId + ", ownerName=" + ownerName
				+ ", businessName=" + businessName + ", email=" + email
				+ ", mobileNo=" + mobileNo + ", isactive=" + isactive + "]";
	}
	
	
}
