package com.cg.reg.exception;

public class FirmException extends Exception{

	public FirmException(String msg) {
		super(msg);
		
	}

}
