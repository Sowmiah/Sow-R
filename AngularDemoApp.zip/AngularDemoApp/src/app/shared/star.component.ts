import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { map } from 'rxjs/operators';
import { of } from 'rxjs';

const num = of(1,2,3);

const squareVal = map((val : number) => val * val);
const squareNums = squareVal(num);


@Component({
  selector: 'app-star',
  templateUrl: './star.component.html',
  styleUrls: ['./star.component.css']
})
export class StarComponent implements OnInit {

  @Input() rating: number;
  starWidth: number = 0;
  @Output() notify : EventEmitter<string> = new EventEmitter<string>();

  constructor() { }

  ngOnInit() {
    this.starWidth = this.rating * 75/5;
  }

  onClick() {
    this.notify.emit('clicked '  + this.rating);
  }

}
