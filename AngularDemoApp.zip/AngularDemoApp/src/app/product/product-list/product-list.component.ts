import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';

import { ProductListService } from './product-list.service';
import { IProduct } from '../product';

@Component({
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  

  private products : IProduct[];
  errorMessage : '';
  filteredProducts: IProduct[] = [];
  constructor(private productService : ProductListService, private router: Router) { }

  ngOnInit() {
     this.productService.getProducts().subscribe({
      next : products => this.products = products,
      error : err => this.errorMessage = err
     }); 
  }

  onNotify(message : string) : void {
    console.log(message);
  }
  openMsg(): void {
    console.log('dfd');
    this.router.navigate([{ outlets: { popup: ['messages'] } }]);
  }

}
