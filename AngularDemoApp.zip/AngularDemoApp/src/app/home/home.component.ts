import { Component, OnInit } from '@angular/core';
import { Observable, merge } from 'rxjs';

@Component({
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {

    const observerable1  = Observable.create((observer: any) => {
      observer.next("I love you")
    });

    const observable2 = Observable.create((observer: any) => {
      observer.next("ofcourse")
    });

    const observable3 = merge(observerable1, observable2);

    observable3.subscribe((data) => console.log(data));   
  }

}
