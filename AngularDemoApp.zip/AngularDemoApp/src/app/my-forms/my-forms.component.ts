import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './my-forms.component.html',
  styleUrls: ['./my-forms.component.css']
})
export class MyFormsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
