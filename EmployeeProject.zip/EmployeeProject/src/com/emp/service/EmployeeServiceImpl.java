package com.emp.service;

import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.dao.IEmployeeDao;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {

	private IEmployeeDao employeeDao = new EmployeeDaoImpl();// RSH implements
																// LHS

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id=0;
		if(validate(bean)){
		id = employeeDao.addEmployee(bean);
		}
		/*int id=0;
		//booleanflag = false;
		if (validateEmployeeName(bean.getEmployeeName())) {
			id = employeeDao.addEmployee(bean);
		} else {
			throw new EmployeeException("Employee Name should be atleast 4 characters");
		}
		//return flag;
		return id;*/
		return id;
	}
	public boolean validateEmployeeName(String name) {
		boolean flag = false;
		Pattern pattern = Pattern.compile("^[A-Za-z]{4,}$");
		Matcher matcher = pattern.matcher(String.valueOf(name));
		if (matcher.matches())
			flag = true;
		else
			flag = false;
		return flag;
	}
	public boolean validateEmployeeId(int id) {
		boolean flag = false;
		Pattern pattern = Pattern.compile("^[0-9]{4}$");
		Matcher matcher = pattern.matcher(String.valueOf(id));
		if (matcher.matches())
			flag = true;
		else
			flag = false;
		return flag;
	}

	@Override
	public EmployeeBean findEmployeeById(int id) throws EmployeeException {
		EmployeeBean bean;
		bean=employeeDao.findEmployeeById(id);
		return bean;
	}

	@Override
	public int deleteEmployeeId(int id) throws EmployeeException {
		EmployeeBean bean;
		int res=employeeDao.deleteEmployeeById(id);
		return res;
	}

	@Override
	public List<EmployeeBean> viewAllEmployee() throws EmployeeException {
		
			
		
		return employeeDao.viewAllEmployees();
	}
	@Override
	public boolean validate(EmployeeBean bean) throws EmployeeException {
		if(!validateEmployeeName(bean.getEmployeeName())){
			throw new EmployeeException("Name is not valid");
		}
		/*if(!validateEmployeeId(bean.getEmployeeId())){
			throw new EmployeeException("Invalid Id");
		}*/
		return true;
	}

}
