package com.emp.service;

import java.util.List;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface IEmployeeService {
	public int addEmployee(EmployeeBean bean) throws Exception;
	public EmployeeBean findEmployeeById(int id) throws EmployeeException;
	public int deleteEmployeeId(int id) throws EmployeeException;
	List<EmployeeBean> viewAllEmployee() throws EmployeeException;
	public boolean validate(EmployeeBean bean) throws EmployeeException;
}
