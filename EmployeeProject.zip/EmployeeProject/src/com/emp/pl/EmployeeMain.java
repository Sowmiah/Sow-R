package com.emp.pl;

import java.util.List;
import java.util.Scanner;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.service.EmployeeServiceImpl;
import com.emp.service.IEmployeeService;

public class EmployeeMain {

	public static void main(String[] args) {
		EmployeeBean emp=new EmployeeBean();
		Scanner scr = new Scanner(System.in);
		IEmployeeService employeeService = new EmployeeServiceImpl();
		while(true){
			System.out.println("1.Add the Employees");
			System.out.println("2.Display the details");
			System.out.println("3.Find Employee by id");
			System.out.println("4.Delete the details");
			System.out.println("Enter your Choice");
			int choice = scr.nextInt();
			scr.nextLine();
			switch(choice){
			case 1:
			{
				System.out.println("Enter the Employee Name");
				String name = scr.nextLine();
				System.out.println("Enter the Salary");
				double salary = scr.nextDouble();

				//EmployeeBean emp = new EmployeeBean();
				/*emp.setEmployeeId(id);*/
				emp.setEmployeeName(name);
				emp.setEmployeeSalary(salary);
				try {
					int id = employeeService.addEmployee(emp);
					if(id>0){
						System.out.println("Employee added");
					}
					else
						System.out.println("Failed");
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				break;
			}
			case 2:
			{
				try {
					List<EmployeeBean> list=employeeService.viewAllEmployee();
					for(EmployeeBean bean : list){
						System.out.println(bean.getEmployeeId()+" "+bean.getEmployeeName()+" "+bean.getEmployeeSalary());
					}
				} catch (EmployeeException e1) {
					System.out.println(e1.getMessage());
				}
				break;
			}
			case 3:
			{
				System.out.println("Enter Emp Id");
				EmployeeBean bean=new EmployeeBean();
				int id1 = scr.nextInt();
				scr.nextLine();
				try {
					
					bean=employeeService.findEmployeeById(id1);
					if(bean.getEmployeeId()!=0){
						System.out.println(bean);
					}
					else{
						System.out.println("ID not found");
					}
				} catch (EmployeeException e1) {
					System.out.println("ID not found"+id1);
				}
				break;
			}
			case 4:
			{
				System.out.println("Enter Emp Id");
				
				int id1 = scr.nextInt();
				scr.nextLine();
				try {
					
					int res=employeeService.deleteEmployeeId(id1);
					if(res>0)
						System.out.println("Record Deleted");
					else
						System.out.println("Deletion Failed");
				} catch (EmployeeException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				break;
			}
			}

		//boolean flag = false;
		

		/*if (flag) {
			System.out.println("EMPLOYEE ADDED SUCCESS");
		}

		else {
			System.out.println("EMPLOYEE FAIL TO ADD");
		}*/
		
		}
	}
}
