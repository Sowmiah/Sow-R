package com.emp.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.emp.exception.EmployeeException;

public class DBConnection {
	public static Connection getConnection() throws EmployeeException{
		Connection con=null;
		Properties prop = new Properties();
		FileReader fr=null;
		try {
			fr = new FileReader("resources/jdbc.properties");
		} catch (FileNotFoundException e) {
			throw new EmployeeException("JDBC FILE NOT FOUND"+e.getMessage());
		}
		//Class.forName("oracle.jdbc.driver.OracleDriver");
		try {
			prop.load(fr);
		} catch (IOException e) {
			throw new EmployeeException("UNABLE TO READ JDBC PROPS FILE"+e.getMessage());
		}
		
		String driver=prop.getProperty("driver");
		String url=prop.getProperty("dburl");
		String user=prop.getProperty("dbuser");
		String pass=prop.getProperty("dbpass");

		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		try {
			con = DriverManager.getConnection(url,user,pass);
		} catch (SQLException e) {
			throw new EmployeeException("SQL EXCEPTION"+e.getMessage());
		}
		/*try {
			con.setAutoCommit(false);
		} catch (SQLException e) {
			throw new EmployeeException("DATABASE CONNECTION FAILED"+e.getMessage());
		}*/
		return con;
	}
}
