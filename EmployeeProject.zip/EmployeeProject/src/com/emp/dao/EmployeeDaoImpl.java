package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImpl implements IEmployeeDao {

	//private Map<Integer, EmployeeBean> map = new HashMap<Integer, EmployeeBean>();
	private static Logger log=Logger.getLogger(EmployeeDaoImpl.class);
	
			public EmployeeDaoImpl(){
				PropertyConfigurator.configure("resources/log4j.properties");
	}
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id=0;
		log.debug("Connection Success");
		try {
			Connection con=DBConnection.getConnection();
			String qry=QueryMapper.INSERT_QUERY;
			PreparedStatement pstmt=con.prepareStatement(qry); 
			pstmt.setString(1, bean.getEmployeeName());
			pstmt.setDouble(2, bean.getEmployeeSalary());
			int count = pstmt.executeUpdate();
			if(count <= 0){
				log.info("insertion failed");
				throw new EmployeeException("INSERT FAIL");
			}
			qry=QueryMapper.SELECT_ID_QUERY;
			pstmt=con.prepareStatement(qry);
			ResultSet rst=pstmt.executeQuery();
			if(rst.next()){
				id=rst.getInt(1);
			}
			else{
				log.info("Read failed");
				throw new EmployeeException("UNABLE TO READ FROM SEQ");
			}
		} catch (SQLException e) {

			throw new EmployeeException(e.getMessage());
		}
		return(id);	
	}

	/*public boolean addEmployee(EmployeeBean bean) throws EmployeeException {

		boolean flag=false;
		if(map==null){
			throw new EmployeeException("MAP NOT EXIST");
		}

		if (map.containsKey(bean.getEmployeeId())) {
			
			flag=false;

		}
		else{
			map.put(bean.getEmployeeId(),bean);
			flag=true;
		}
		return(flag);

	}*/


	@Override
	public EmployeeBean findEmployeeById(int id) {
		EmployeeBean bean=new EmployeeBean();
		try {
			Connection con=DBConnection.getConnection();
			
			String qry=QueryMapper.WHERE_QUERY;
			PreparedStatement pstmt=con.prepareStatement(qry);
			pstmt.setInt(1, id);
			ResultSet rst=pstmt.executeQuery();
			if(rst.next()){
				bean.setEmployeeId(rst.getInt("empid"));
				bean.setEmployeeName(rst.getString("empname"));
				bean.setEmployeeSalary(rst.getDouble("empsalary"));
			}
			if(bean!=null){
				return bean;
			}
			
		} catch (SQLException e) {
			System.out.println("SQL Exception is thrown");
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bean;
	}


	@Override
	public int deleteEmployeeById(int id) throws EmployeeException {
		EmployeeBean bean=new EmployeeBean();
		int res=0;
		try {
			Connection con=DBConnection.getConnection();
			
			String qry=QueryMapper.DELETE_QUERY;
			PreparedStatement pstmt=con.prepareStatement(qry);
			pstmt.setInt(1, id);
			res=pstmt.executeUpdate();
			con.close();
		} catch (SQLException e) {
			System.out.println("SQL Exception is thrown");
		}

		return res;
	}


	@Override
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException {
		List<EmployeeBean> list=new ArrayList<EmployeeBean>();
		try {
			Connection con=DBConnection.getConnection();
			String qry=QueryMapper.SELECT_ALL_EMP_QUERY;
			PreparedStatement pstmt=con.prepareStatement(qry);
			ResultSet rst=pstmt.executeQuery();
			while(rst.next()){
				EmployeeBean bean=new EmployeeBean();
				
				bean.setEmployeeId(rst.getInt("empid"));
				bean.setEmployeeName(rst.getString("empname"));
				bean.setEmployeeSalary(rst.getDouble("empsalary"));
				
				list.add(bean);
			}
			con.close();
		} catch (SQLException e) {
			throw new EmployeeException("EXCEPTION IN VIEW ALL EMPLOYEES"+e.getMessage());
		}
		return list;
	}

	}

