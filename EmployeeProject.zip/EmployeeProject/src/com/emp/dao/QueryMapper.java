package com.emp.dao;

public interface QueryMapper {
public static final String SELECT_ID_QUERY="select emp_seq.currval from emp_tbl";
 public static final String INSERT_QUERY="insert into emp_tbl(empid,empname,empsalary) values (emp_seq.nextval,?,?)";
 public static final String SELECT_ALL_EMP_QUERY="select empid,empname,empsalary from emp_tbl";
 public static final String WHERE_QUERY="select empid,empname,empsalary from emp_tbl where empid=?";
 public static final String DELETE_QUERY="delete from emp_tbl where empid=?";
}
