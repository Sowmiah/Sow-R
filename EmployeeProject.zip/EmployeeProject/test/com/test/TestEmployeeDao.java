package com.test;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;




import static org.junit.Assert.*;


import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.exception.EmployeeException;

public class TestEmployeeDao {
	static EmployeeDaoImpl dao;
	static EmployeeBean bean;
	
	@BeforeClass
	public static void init()
	{
		dao=new EmployeeDaoImpl();
		bean=new EmployeeBean();
	}
	@Test
	public void testAddEmployee() throws EmployeeException
	{
		bean.setEmployeeName("Amar");
		bean.setEmployeeSalary(23000);
		Integer id=dao.addEmployee(bean);
		assertNotNull(id);
		
	}
	@Test
	public void testViewAll() throws EmployeeException
	{
		assertNotNull(dao.viewAllEmployees());
	}
	
	//@Ignore
	@Test
	public void testById1() throws EmployeeException {
		bean.setEmployeeId(1001);
		assertNotNull(dao.findEmployeeById(1001));

	}
	@Test
	public void deleteById() throws EmployeeException{
		bean.setEmployeeId(2033);
		assertNotNull(dao.deleteEmployeeById(2033));
	}
	
}
