var myQuestions = [
	{
		question: " What would be the behaviour if this() and super() used in a method?",
		answers: {
			a: 'Runtime error',
			b: 'Throws exception',
			c: 'compile time error',
			d: 'Runs successfully'
		},
		correctAnswer: 'c'
	},
	{
		question: "What would be behaviour if constructor has a return type?",
		answers: {
			a: 'Compilation error',
			b: 'Runtime error',
			c: 'Compilation and runs successfully',
			d: 'Only String return type is allowed'
		},
		correctAnswer: 'a'
	},
	{	
		question: "Abstract class cannot have a constructor.",
		answers: {
			a: 'True',
			b: 'False',
			
		},
		correctAnswer: 'b'
		
	},
	{	
		question: "What is not the use of \"this\" keyword in Java?",
		answers: {
			a: 'Passing itself to another method',
			b: 'Calling another constructor in constructor chaining',
			c: 'Referring to the instance variable when local variable has the same name',
			d: 'Passing itself to method of the same class'
			
		},
		correctAnswer: 'd'
		
	}
];




function generateQuiz(questions, quizContainer, resultsContainer, submitButton){

	
	function showQuestions(questions, quizContainer){
		
	var output = [];
	var answers;

	
	for(var i=0; i<questions.length; i++){
		
		
		answers = [];

		
		for(letter in questions[i].answers){

			
			answers.push(
				'<label>'
					+ '<input type="radio" name="question'+i+'" value="'+letter+'">'
					+ letter + ': '
					+ questions[i].answers[letter]
				+ '</label>'
				+'<br/>'
			);
		}

		
		output.push(
			'<div class="question">'+ questions[i].question + '</div>'
			+ '<div class="answers">' + answers.join('') + '</div>'
		);
	}

	quizContainer.innerHTML = output.join('');
		
	}
	
		$("#submit").show();

	function showResults(questions, quizContainer, resultsContainer){
			
	var answerContainers = quizContainer.querySelectorAll('.answers');
	
	
	var userAnswer = '';
	var numCorrect = 0;
	
	
	for(var i=0; i<questions.length; i++){

		
		userAnswer = (answerContainers[i].querySelector('input[name=question'+i+']:checked')||{}).value;
		
		
		if(userAnswer===questions[i].correctAnswer){
			
			numCorrect++;
			
			
			answerContainers[i].style.color = 'lightgreen';
		}
		
		else{
			
			answerContainers[i].style.color = 'red';
		}
	}


	resultsContainer.innerHTML = 'Your Score : ' + numCorrect + ' out of ' + questions.length;
		
	}

	
	showQuestions(questions, quizContainer);

	
	submitButton.onclick = function(){
		showResults(questions, quizContainer, resultsContainer);
	}
}



$(document).ready(function(){
	$("#submit").hide();
	
    $("p").click(function(){
		$(this).hide();
		$("#main").css({"overflow": "scroll", "overflow-x": "hidden"});
       var quizContainer = document.getElementById('quiz');
var resultsContainer = document.getElementById('results');
var submitButton = document.getElementById('submit');

generateQuiz(myQuestions, quizContainer, resultsContainer, submitButton);
    });
});