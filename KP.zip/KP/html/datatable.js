$(document).ready(function () {
        $('.table').DataTable({
           "pagingType": "numbers",
			"bFilter": false,
		   "bPaginate": false
          
         });
    });