package com.hotel.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="hotel")
public class HotelBean {

	
	@Override
	public String toString() {
		return "HotelBean [hotelId=" + hotelId + ", hotelName=" + hotelName
				+ ", city=" + city + ", lunchTime=" + lunchTime + ", bookingStatus="
				+ bookingStatus +  "]";
	}
	
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private int hotelId;
	
	@NotEmpty(message="Please Enter Hotel Name")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Hotelname must contain only alphabets")
	private String hotelName;
	
	@NotEmpty(message="Please Enter City")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "City must contain only alphabets")
	private String city;
	
	
	private String lunchTime;
	private String bookingStatus;
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLunchTime() {
		return lunchTime;
	}
	public void setLunchTime(String lunchTime) {
		this.lunchTime = lunchTime;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	
	
	
}
