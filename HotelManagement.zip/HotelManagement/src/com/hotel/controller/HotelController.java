/*package com.hotel.controller;

import java.time.LocalDate;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hotel.bean.HotelBean;
import com.hotel.service.IHotelService;


@Controller
public class HotelController {

	@Autowired
	private IHotelService service;
	
	
	public IHotelService getService() {
		return service;
	}


	public void setService(IHotelService service) {
		this.service = service;
	}


	@RequestMapping("/showHomePage")
	public String showHomePage() {
		return "index";
	}

	@RequestMapping("/showHomeForm")
	public ModelAndView showHomeForm() {
		HotelBean hotel = new HotelBean();
		return new ModelAndView("index", "hotel", hotel);
	}
	
	@RequestMapping("/show")
	public ModelAndView show(@ModelAttribute("hotel") @Valid HotelBean hotel,BindingResult result) {
		ModelAndView mv = new ModelAndView();
		if (!result.hasErrors()) {
		mv.addObject("hotelName",hotel.getHotelName());
		mv.addObject("city",hotel.getCity());
		mv.setViewName("show");
		}
		else {
			mv = new ModelAndView("index", "hotel", hotel);
		}
		return mv;
	}
	
	@RequestMapping("/show")
	public ModelAndView viewTrainee(@ModelAttribute("hotel") @Valid HotelBean hotel,BindingResult result) {

		ModelAndView mv = new ModelAndView();
		HotelBean dbean = new HotelBean();
		if (!result.hasErrors()) {
			mv.addObject("hotelName",hotel.getHotelName());
			mv.addObject("city",hotel.getCity());
			//mv.setViewName("show");
		dbean = service.getHotelDetails(hotel.getHotelName(),hotel.getCity());
		if (dbean !=null) {
			mv.setViewName("show");
			mv.addObject("dbean", dbean);
		} else {
			String msg = "Enter a Valid Name!!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}
		}
		else {
			mv = new ModelAndView("index", "hotel", hotel);
		}
		return mv;
	}
	
	@RequestMapping("/Modify")
	public ModelAndView modify(@ModelAttribute("hotel") HotelBean hotel ) {

		ModelAndView mv = new ModelAndView();
		
		
		HotelBean dbean = service.getHotelDetails(hotel.getHotelName(),hotel.getCity());
		System.out.println(dbean);
		if (dbean != null) {
			dbean.setBookingStatus("Booked");
			service.modifyBookingDetail(dbean);
			mv.setViewName("updateSuccess");
			String date=LocalDate.now().toString();
			mv.addObject("date", date);
			mv.addObject("dbean", dbean);
		} else {
			String msg = "Enter a Valid Name!!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}

		return mv;
	}		
}*/

package com.hotel.controller;

import java.time.LocalDate;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndView;

import com.hotel.bean.HotelBean;
import com.hotel.service.IHotelService;




@Controller
public class HotelController {

    @Autowired
    IHotelService service;

    public IHotelService getService() {
        return service;
    }

    public void setService(IHotelService service) {
        this.service = service;
    }
    String name="";
    String city="";
    @RequestMapping("/showHomeForm")
    public ModelAndView showHomeForm() {
    HotelBean hotel=new HotelBean();
    return new ModelAndView("index","hotel",hotel);
    }
    
    @RequestMapping("/show")
    public ModelAndView show(@ModelAttribute("hotel") @Valid HotelBean hotel,BindingResult result) {
        ModelAndView mv = new ModelAndView();
        if (!result.hasErrors()) {
            
    mv.addObject("hotelName",hotel.getHotelName());
    mv.addObject("city", hotel.getCity());
 name=hotel.getHotelName();
 city=hotel.getCity();
    HotelBean dbean=service.getHotelDetails(hotel.getHotelName(), hotel.getCity());
    if(dbean!=null)
    {
        mv.addObject("dbean", dbean);
        }
    else
    {
        String msg="Enter a valid name and city";
        mv.setViewName("myError");
        mv.addObject("msg", msg);
    }
}
        else {
            mv = new ModelAndView("index", "hotel", hotel);
        }

        return mv;
        
}
    @RequestMapping("/Modify")
    public ModelAndView book(@ModelAttribute("hotel") HotelBean hotel) {

        ModelAndView mv = new ModelAndView();
        HotelBean dbean=service.getHotelDetails(name,city);
        if(dbean!=null)
        {
            dbean.setBookingStatus("booked");
            service.modifyBookingDetail(dbean);
            mv.setViewName("updateSuccess");
            String date=LocalDate.now().toString();
            mv.addObject("date",date);
        }
        else
        {
            String msg="Enter a Valid name and city";
            mv.setViewName("myError");
            mv.addObject("msg",msg);
        }
        return mv;
    }
    
}

