package com.hotel.dao;

import com.hotel.bean.HotelBean;


public interface IHotelDao {

	//public HotelBean addHotel(HotelBean hotel);
	public HotelBean getHotelDetails(String hotelName,String city);
	public void modifyBookingDetail(HotelBean hotel);
}
