package com.hotel.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.hotel.bean.HotelBean;

@Repository
@Transactional
public class HotelDaoImpl implements IHotelDao {

	@PersistenceContext
	private EntityManager entityManager;

	/*@Override
	public HotelBean addHotel(HotelBean hotel) {		
		entityManager.persist(hotel);
		entityManager.flush();
		return hotel;
	}
*/
	@Override
	public HotelBean getHotelDetails(String hotelName,String city) {
		TypedQuery<HotelBean> qry=entityManager.createQuery("From HotelBean where hotelName=? and city=?",HotelBean.class);
		qry.setParameter(1, hotelName);
		qry.setParameter(2, city);
		return qry.getSingleResult();
	}

	@Override
	public void modifyBookingDetail(HotelBean hotel) {
		entityManager.merge(hotel);
		
	}
}
