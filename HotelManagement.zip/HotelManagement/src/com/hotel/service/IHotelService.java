package com.hotel.service;

import com.hotel.bean.HotelBean;

public interface IHotelService {

	/*public HotelBean addHotel(HotelBean hotel);*/
	public HotelBean getHotelDetails(String hotelName,String city);
	public void modifyBookingDetail(HotelBean hotel);
	
}
