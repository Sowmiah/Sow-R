package com.hotel.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.bean.HotelBean;
import com.hotel.dao.IHotelDao;

@Service
public class HotelServiceImpl implements IHotelService {

	@Autowired
	IHotelDao dao;

	public IHotelDao getDao() {
		return dao;
	}
	public void setDao(IHotelDao dao) {
		this.dao = dao;
	}
	
	@Override
	public HotelBean getHotelDetails(String hotelName,String city) {
		// TODO Auto-generated method stu
		return dao.getHotelDetails(hotelName,city);
	}
	@Override
	public void modifyBookingDetail(HotelBean hotel) {
		dao.modifyBookingDetail(hotel);
		
	}


	/*@Override
	public HotelBean addHotel(HotelBean hotel) {
		//set todays date as donation date		
		return dao.addHotel(hotel);
	}
*/}
