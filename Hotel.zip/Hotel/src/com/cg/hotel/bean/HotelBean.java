package com.cg.hotel.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hotel")
public class HotelBean {

	@Id
	private int id;
	private String hotelName;
	private String city;
	private String lunchTime;
	private String bookingStatus;
	public HotelBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLunchTime() {
		return lunchTime;
	}
	public void setLunchTime(String lunchTime) {
		this.lunchTime = lunchTime;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public HotelBean(int id, String hotelName, String city, String lunchTime,
			String bookingStatus) {
		super();
		this.id = id;
		this.hotelName = hotelName;
		this.city = city;
		this.lunchTime = lunchTime;
		this.bookingStatus = bookingStatus;
	}
	@Override
	public String toString() {
		return "HotelBean [id=" + id + ", hotelName=" + hotelName + ", city="
				+ city + ", lunchTime=" + lunchTime + ", bookingStatus="
				+ bookingStatus + "]";
	}
	
	
}
