package com.cg.hotel.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hotel.bean.HotelBean;
import com.cg.hotel.service.IHotelService;




@Controller
public class HotelController {
	String name="";
	String city="";
	@Autowired
	private IHotelService service;

	public IHotelService getService() {
		return service;
	}
	public void setService(IHotelService service) {
		this.service = service;
	}
	@RequestMapping("/index1")
	public String indexHome(){
		
		return "index1";
		
	}
	@RequestMapping("/index")
	public ModelAndView index(){
		
		HotelBean bean = new HotelBean();
		return new ModelAndView("index","bean",bean);
		
	}
	@RequestMapping("/searchById")
	public ModelAndView searchHotel(@ModelAttribute("bean") HotelBean bean){
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("hotelName", bean.getHotelName());
		mv.addObject("city",bean.getCity());
		name=bean.getHotelName();
		city=bean.getCity();
		HotelBean hotel = new HotelBean();
		
		hotel=service.searchHotel(bean.getHotelName(),bean.getCity());
	
		System.out.println(hotel);
		//mv.setViewName("searchHotel");
		if (hotel != null) {
			
			mv.setViewName("searchHotel");
			mv.addObject("hotel",hotel);
		} else 
		{
			String msg = "Enter a Valid Hotel Name!!";
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		
		
		return mv;
		
		
	}
	
	@RequestMapping("/book")
	public ModelAndView modify(@ModelAttribute("hotel") HotelBean hotel){
		
		ModelAndView mv = new ModelAndView();
		HotelBean bean=service.searchHotel(name,city);
		//System.out.println(bean.getBookingStatus());
		
		if (bean != null) {
			bean.setBookingStatus("booked");
			System.out.println(bean.getBookingStatus());
			service.updateStatus(bean);
			
			mv.setViewName("booked");
			String date=LocalDate.now().toString();
			mv.addObject("date", date);
		} 
		 else {
				
				String msg = "Enter a Valid Id!!";
				mv.setViewName("error");
				mv.addObject("msg", msg);
			}
		return mv;
	}
	/*@RequestMapping("/search")
	public ModelAndView viewHotel(@ModelAttribute("bean") HotelBean bean) {

		ModelAndView mv = new ModelAndView();

		HotelBean hotel = new HotelBean();
		System.out.println("working");
		hotel=service.searchHotel(bean.getHotelName());
		System.out.println(hotel);
		//bean=service.getTraineeDetails(trainee.getTraineeId());
		
		if (hotel != null) {
		
			mv.addObject("hotelname", hotel.getHotelName());
			mv.addObject("city", hotel.getCity());
			mv.setViewName("searchHotel");
		} else 
		{
			String msg = "Enter a Valid Hotel Name!!";
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}

		return mv;
	}*/
}
