package com.cg.hotel.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hotel.bean.HotelBean;
import com.cg.hotel.dao.IHotelDao;

@Service
public class HotelServiceImpl implements IHotelService {

	@Autowired
	private IHotelDao dao;
	
	
	public IHotelDao getDao() {
		return dao;
	}


	public void setDao(IHotelDao dao) {
		this.dao = dao;
	}


	@Override
	public HotelBean searchHotel(String name,String city) {
		return dao.searchHotel(name, city);
	}


	@Override
	public void updateStatus(HotelBean bean) {
		dao.updateStatus(bean);
		
	} 

	
}
