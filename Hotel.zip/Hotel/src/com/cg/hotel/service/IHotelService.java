package com.cg.hotel.service;

import com.cg.hotel.bean.HotelBean;

public interface IHotelService {


	public HotelBean searchHotel(String name, String city);
	public void updateStatus(HotelBean bean);
}
