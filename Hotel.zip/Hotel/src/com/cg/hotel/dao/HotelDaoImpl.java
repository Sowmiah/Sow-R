package com.cg.hotel.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.hotel.bean.HotelBean;

@Repository
@Transactional
public class HotelDaoImpl implements IHotelDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	

	@Override
	public HotelBean searchHotel(String name,String city) {
		HotelBean bean =null;
		try {
			TypedQuery<HotelBean> qry=entityManager.createQuery("From HotelBean where hotelName=? and city=?",HotelBean.class);
			qry.setParameter(1, name);
			qry.setParameter(2, city);
			
			bean=qry.getSingleResult();
		} catch (Exception e) {
			
		}
		return bean;
	}

	@Override
	public void updateStatus(HotelBean bean) {
		
		entityManager.merge(bean);
		
	}

	
}
