package com.cg.hotel.dao;

import com.cg.hotel.bean.HotelBean;

public interface IHotelDao {

	public HotelBean searchHotel(String name, String city);
	public void updateStatus(HotelBean bean);
}
